#!/usr/bin/env python3
from hyperweave.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
