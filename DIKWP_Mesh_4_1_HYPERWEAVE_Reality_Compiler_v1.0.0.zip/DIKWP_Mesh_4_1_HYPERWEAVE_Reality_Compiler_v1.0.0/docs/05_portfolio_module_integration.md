# 05 项目组合模块接入图

## 1. 接口原则

HYPERWEAVE 不直接执行段玉聪仓库代码，而是把公开材料中观察到的输入、输出、能力和局限保存为本地清单。这样可以：

- 保留来源和观察时间；
- 防止仓库名称被误作已验证能力；
- 将跨项目组合问题转换为可校验的本地类型关系；
- 避免外部仓库更新静默改变已编译胶囊；
- 明确任何模块都不能自动传递现实权威。

## 2. 13 个模块

| 本地模块 ID | 主要进入点 | 在编译胶囊中的对象 |
|---|---|---|
| `module_mesh_runtime` | 来源化表达与关系地址 | source manifest、mesh、residuals |
| `module_intentfield` | 多目的激活子网 | intent-conditioned kernel |
| `module_pact` | 目的与权限保持 | purpose contracts、authority obligations |
| `module_mandate` | 多主体授权和权利 | authority envelope、hard gates、recovery |
| `module_credence` | 主张级证据 | source manifest、certificate evidence state |
| `module_aion` | 预注册结果与时间 | settlement contract、observation comparison |
| `module_praxis` | 使命与行动组合 | mission sequence、action portfolio |
| `module_realityloop` | 观察和学习 | settlement records |
| `module_nexus_forge` | 模块清单和静态组合 | module pipeline、manifest hashes |
| `module_civicloop` | 受影响方与申诉 | actor rights、appeal/recovery paths |
| `module_immunet` | 联邦事件与恢复 | stop/recovery relations、federation |
| `module_trustdistill` | 证明携带发行 | proof certificate、release boundary |
| `module_waeg` | 跨节点证据交换 | evidence bundle、authority non-inheritance |

## 3. 类型关系

一个任务可声明 `module_pipeline`，编译器检查引用清单存在，并将其固定进胶囊。1.0.0 不自动调用远程模块，也不假设下列关系成立：

```text
名称相同 → 语义相同
README 声称 → 运行已经验证
清单匹配 → 现场可部署
哈希一致 → 内容真实
证据可交换 → 权威可交换
```

## 4. 组合级闭合

HYPERWEAVE 将模块作用安排为：

```text
NEXUS-FORGE：静态接口和发行材料
MESH Runtime：来源化关系地址
INTENTFIELD / PACT：目的和保持义务
MANDATE / CIVICLOOP：授权、权利、申诉和恢复
PRAXIS：任务序列
形式编译器：状态空间、义务和反例
CREDENCE / TRUSTDISTILL：证明和证据状态
AION / RealityLoop：观察结算
IMMUNET / WAEG：联邦交换和权威不继承
```

上述安排是本项目的工程编排，不是这些项目的官方依赖图。
