# 02 系统架构

## 1. 分层结构

```text
┌─────────────────────────────────────────────────────────────┐
│ 浏览器工作台 / CLI / OpenAPI 3.1                           │
├─────────────────────────────────────────────────────────────┤
│ Service：身份、修订、编译、结算、导入导出、审计            │
├─────────────────────────────────────────────────────────────┤
│ Reality Compiler                                             │
│  ├─ Module manifest resolver                                 │
│  ├─ Explicit-state model checker                             │
│  ├─ Seeded descriptive branch sampler                        │
│  ├─ Intent-conditioned deletion kernel                       │
│  ├─ DIKWP×DIKWP active mesh builder                          │
│  └─ Proof-carrying capsule assembler                         │
├─────────────────────────────────────────────────────────────┤
│ Settlement / Federation                                      │
│  ├─ Pre-registered expression settlement                     │
│  ├─ Redaction                                                │
│  ├─ SHA-256 / HMAC demonstration                             │
│  └─ authority_inherited=false                                │
├─────────────────────────────────────────────────────────────┤
│ SQLite WAL / optimistic revision / audit hash chain          │
└─────────────────────────────────────────────────────────────┘
```

## 2. 输入对象

### 2.1 场景

场景是一个带来源的有限实验描述，包含：

- 观察者与范围；
- 主体；
- 原始目的表达；
- 状态变量及类型和边界；
- 动作、前置条件和一个或多个带权重分支；
- 任务候选；
- 预注册假设和结算表达；
- 来源证据与非主张。

分支权重用于合成抽样，不改变形式检查对每个可达分支的枚举关系。

### 2.2 模块清单

模块清单将公开项目的能力表达转换为声明式接口：

```json
{
  "id": "module_pact",
  "source_state": "readme_observed",
  "input_artifacts": ["signed purpose", "permission boundary"],
  "output_artifacts": ["assurance result", "counterexample case"],
  "integration_slots": ["purpose_contract", "permission_obligation"],
  "limitations": ["..." ]
}
```

模块清单不加载或执行远程仓库代码，也不继承远程仓库的权威。

## 3. 编译阶段

1. 校验场景结构、表达语法、引用和变量类型；
2. 解析任务引用的模块清单；
3. 从初始状态按任务序列展开全部声明分支，直到终止、停止条件或状态上限；
4. 在初始和每一步状态上检查不变量；
5. 检查有限步长活性；
6. 检查每个动作所需权限是否被任务信封授予；
7. 检查不可逆动作与恢复声明；
8. 保存每个义务的状态和最短已发现反例；
9. 计算各目的在所有终态分支上的逐项状态；
10. 生成结果范围和唯一终态摘要；
11. 进行带种子的描述性抽样；
12. 对目的、动作、不变量和权限做删除式反事实测试；
13. 形成当前激活的 DIKWP×DIKWP 关系网；
14. 固化来源、运行环境、哈希、开放残差和非主张。

## 4. 输出对象

输出为不可静默修改的编译记录，核心对象是 `capsule`：

```text
scenario
mission
purpose_contracts
authority_envelope
source_manifest
module_pipeline
formal
simulation
intent_conditioned_kernel
mesh
settlement_contract
status_dimensions
runtime_manifest
proof_carrying_certificate
residuals
non_claims
```

## 5. 本地持久化

SQLite 表包括：

```text
meta
users
sessions
portfolio_projects
module_manifests
scenarios
compilations
settlements
nodes
evidence_imports
audit_events
```

场景采用 `revision` 乐观并发控制。编译记录、结算和证据导入均追加，不覆盖既有结果。审计链以每个事件的前序哈希、载荷哈希和事件材料形成 SHA‑256 链。
