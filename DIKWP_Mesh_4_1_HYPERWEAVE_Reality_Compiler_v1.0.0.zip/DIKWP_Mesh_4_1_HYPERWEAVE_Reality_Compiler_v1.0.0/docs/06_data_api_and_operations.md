# 06 数据、API 与运行

## 1. 运行依赖

- Python 3.10+；
- SQLite，由 Python 标准库提供；
- 支持 ES2021 的现代浏览器；
- 不需要外部模型 API；
- 默认不访问网络。

## 2. 数据初始化

首次启动且数据库为空时，系统加载：

- 6 个演示工作流用户；
- 1 个本地主权节点；
- 129 条项目关系记录；
- 13 个模块清单；
- 4 个场景和 8 个任务候选。

再次启动时按对象主键检查，不覆盖已存在场景，也不会重复插入种子对象。

## 3. API

主要端点：

```text
GET  /api/health
POST /api/login
GET  /api/me
GET  /api/portfolio
GET  /api/modules
GET  /api/scenarios
GET  /api/scenarios/{id}
POST /api/scenarios
GET  /api/compilations
GET  /api/compilations/{id}
POST /api/compile
GET  /api/settlements
POST /api/settlements
POST /api/compilations/{id}/export
POST /api/imports
GET  /api/audit
GET  /api/audit/verify
```

完整契约见 `openapi.yaml`。

## 4. 并发与审计

场景更新必须携带 `expected_revision`。版本不一致返回 HTTP 409。编译和结算对象只追加。

每个写事件保存：

```text
event_id
actor
action
object_type
object_id
payload_hash
prev_hash
event_hash
created_at
```

## 5. 网络边界

服务器默认只监听 `127.0.0.1`。CSP 禁止外部脚本、样式和连接。请求体限制为 5 MB。系统没有 CORS 开放配置，没有内置远程代码执行、shell 调用或工具代理。

## 6. 发行清洁性

正式 ZIP 不应包含：

```text
runtime/*.sqlite3
*.sqlite3-wal
*.sqlite3-shm
__pycache__
*.pyc
测试临时文件
本地令牌
```
