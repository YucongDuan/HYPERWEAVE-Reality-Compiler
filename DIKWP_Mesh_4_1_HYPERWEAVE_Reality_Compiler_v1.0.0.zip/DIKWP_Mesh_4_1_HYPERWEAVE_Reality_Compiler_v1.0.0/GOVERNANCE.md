# Governance

Changes to scenarios, module manifests, proof semantics, role permissions, redaction rules or authority boundaries require explicit revision, source-state preservation and regression tests.

No maintainer may represent a bounded compilation status as real-world authorization, safety certification, legal compliance, clinical validity or endorsement by Yucong Duan or any institution.

External evidence may be imported only as a source-indexed object. Local authority is never inherited from an external package.
