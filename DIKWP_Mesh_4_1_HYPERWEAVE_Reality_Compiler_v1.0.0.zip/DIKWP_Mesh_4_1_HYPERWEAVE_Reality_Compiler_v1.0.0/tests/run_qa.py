from __future__ import annotations

import copy
import hashlib
import http.client
import json
import os
import py_compile
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from collections import defaultdict
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from hyperweave.constants import DIKWP_CHANNELS, PROJECT_BOUNDARY  # noqa: E402
from hyperweave.federation import export_evidence_bundle, verify_evidence_bundle  # noqa: E402
from hyperweave.server import serve  # noqa: E402
from hyperweave.service import ConflictError, Service  # noqa: E402
from hyperweave.util import atomic_write_text, canonical_json, pretty_json, sha256_file  # noqa: E402
from hyperweave.validation import validate_module_manifest, validate_scenario  # noqa: E402

try:
    import jsonschema
except Exception:  # pragma: no cover
    jsonschema = None


class Recorder:
    def __init__(self) -> None:
        self.passed = 0
        self.failed = 0
        self.categories: dict[str, dict[str, int]] = defaultdict(lambda: {"passed": 0, "failed": 0})
        self.failures: list[dict[str, Any]] = []

    def check(self, condition: Any, name: str, category: str, detail: Any = None) -> None:
        if condition:
            self.passed += 1
            self.categories[category]["passed"] += 1
        else:
            self.failed += 1
            self.categories[category]["failed"] += 1
            self.failures.append({"name": name, "category": category, "detail": detail})

    def equal(self, actual: Any, expected: Any, name: str, category: str) -> None:
        self.check(actual == expected, name, category, {"actual": actual, "expected": expected})


rec = Recorder()


def wait_port(port: int, timeout: float = 8.0) -> None:
    deadline = time.time() + timeout
    while time.time() < deadline:
        with socket.socket() as sock:
            sock.settimeout(0.2)
            if sock.connect_ex(("127.0.0.1", port)) == 0:
                return
        time.sleep(0.05)
    raise RuntimeError(f"server did not open port {port}")


def http_json(port: int, method: str, path: str, body: Any = None, token: str | None = None) -> tuple[int, dict[str, Any]]:
    conn = http.client.HTTPConnection("127.0.0.1", port, timeout=10)
    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    payload = json.dumps(body).encode() if body is not None else None
    conn.request(method, path, body=payload, headers=headers)
    response = conn.getresponse()
    data = response.read()
    conn.close()
    try:
        parsed = json.loads(data.decode())
    except Exception:
        parsed = {"raw": data.decode(errors="replace")}
    return response.status, parsed


def static_checks() -> None:
    category = "syntax_and_static"
    py_files = sorted([ROOT / "run.py", *list((ROOT / "hyperweave").glob("*.py")), *list((ROOT / "tests").glob("*.py"))])
    for path in py_files:
        try:
            py_compile.compile(str(path), doraise=True)
            rec.check(True, f"python compile {path.relative_to(ROOT)}", category)
        except Exception as exc:
            rec.check(False, f"python compile {path.relative_to(ROOT)}", category, str(exc))
    node = shutil.which("node")
    if node:
        proc = subprocess.run([node, "--check", str(ROOT / "web" / "app.js")], capture_output=True, text=True)
        rec.check(proc.returncode == 0, "javascript syntax", category, proc.stderr)
    else:
        rec.check(True, "javascript syntax skipped: node unavailable", category)

    index = (ROOT / "web" / "index.html").read_text(encoding="utf-8")
    app = (ROOT / "web" / "app.js").read_text(encoding="utf-8")
    css = (ROOT / "web" / "styles.css").read_text(encoding="utf-8")
    for token in ["loginOverlay", "compileButton", "counterexampleList", "meshMatrix", "bundlePreview", "auditRows"]:
        rec.check(f'id="{token}"' in index, f"web id {token}", category)
        rec.check(f'$("{token}")' in app or token in app, f"web binding {token}", category)
    rec.check("@media" in css, "responsive CSS", category)
    rec.check("Content-Security-Policy" in (ROOT / "hyperweave" / "server.py").read_text(), "CSP header", category)
    rec.check("subprocess" not in (ROOT / "hyperweave" / "server.py").read_text(), "no server shell execution", category)
    rec.check("no_scalar_without_explicit_weights" in (ROOT / "hyperweave" / "compiler.py").read_text(), "non-scalar invariant", category)
    rec.check("不为“现实”“世界”“未来”" in (ROOT / "hyperweave" / "constants.py").read_text(encoding="utf-8"), "engineering handle boundary", category)


def data_and_schema_checks() -> None:
    category = "data_and_schema"
    json_files = sorted([*ROOT.glob("data/**/*.json"), *ROOT.glob("schemas/*.json")])
    parsed: dict[Path, Any] = {}
    for path in json_files:
        try:
            parsed[path] = json.loads(path.read_text(encoding="utf-8"))
            rec.check(True, f"json parse {path.relative_to(ROOT)}", category)
        except Exception as exc:
            rec.check(False, f"json parse {path.relative_to(ROOT)}", category, str(exc))

    scenario_schema = parsed[ROOT / "schemas" / "scenario.schema.json"]
    module_schema = parsed[ROOT / "schemas" / "module_manifest.schema.json"]
    portfolio_schema = parsed[ROOT / "schemas" / "portfolio_snapshot.schema.json"]
    scenario_ids = set()
    mission_ids = set()
    for path in sorted((ROOT / "data" / "scenarios").glob("*.json")):
        payload = parsed[path]
        try:
            validate_scenario(payload)
            rec.check(True, f"custom scenario validation {payload['id']}", category)
        except Exception as exc:
            rec.check(False, f"custom scenario validation {path.name}", category, str(exc))
        if jsonschema:
            try:
                jsonschema.Draft202012Validator(scenario_schema).validate(payload)
                rec.check(True, f"schema scenario {payload['id']}", category)
            except Exception as exc:
                rec.check(False, f"schema scenario {path.name}", category, str(exc))
        rec.check(payload["id"] not in scenario_ids, f"unique scenario {payload['id']}", category)
        scenario_ids.add(payload["id"])
        rec.check(bool(payload["observer_context"]), f"observer context {payload['id']}", category)
        rec.check(bool(payload["purposes"]), f"purposes {payload['id']}", category)
        rec.check(bool(payload["state_variables"]), f"state variables {payload['id']}", category)
        for mission in payload["missions"]:
            rec.check(mission["id"] not in mission_ids, f"unique mission {mission['id']}", category)
            mission_ids.add(mission["id"])
            rec.check(bool(mission["purpose_ids"]), f"mission purpose {mission['id']}", category)
            rec.check(bool(mission["sequence"]), f"mission sequence {mission['id']}", category)
            rec.check(bool(mission["module_pipeline"]), f"mission modules {mission['id']}", category)
    rec.equal(len(scenario_ids), 4, "scenario count", category)
    rec.equal(len(mission_ids), 8, "mission count", category)

    module_ids = set()
    for path in sorted((ROOT / "data" / "module_manifests").glob("*.json")):
        payload = parsed[path]
        try:
            validate_module_manifest(payload)
            rec.check(True, f"custom module validation {payload['id']}", category)
        except Exception as exc:
            rec.check(False, f"custom module validation {path.name}", category, str(exc))
        if jsonschema:
            try:
                jsonschema.Draft202012Validator(module_schema).validate(payload)
                rec.check(True, f"schema module {payload['id']}", category)
            except Exception as exc:
                rec.check(False, f"schema module {path.name}", category, str(exc))
        rec.check(payload["id"] not in module_ids, f"unique module {payload['id']}", category)
        module_ids.add(payload["id"])
        rec.check(payload["source_url"].startswith(("https://", "local-")), f"module source {payload['id']}", category)
        rec.check(bool(payload["limitations"]), f"module limits {payload['id']}", category)
        rec.check(bool(payload["integration_slots"]), f"module slots {payload['id']}", category)
    rec.equal(len(module_ids), 13, "module count", category)

    portfolio = parsed[ROOT / "data" / "portfolio_snapshot.json"]
    if jsonschema:
        try:
            jsonschema.Draft202012Validator(portfolio_schema).validate(portfolio)
            rec.check(True, "portfolio schema", category)
        except Exception as exc:
            rec.check(False, "portfolio schema", category, str(exc))
    rec.equal(portfolio["observed_repository_total"], 220, "observed repository count", category)
    rec.equal(portfolio["observed_starred_total"], 240, "observed star page count", category)
    rec.equal(portfolio["curated_project_count"], 129, "curated portfolio count", category)
    rec.equal(len(portfolio["projects"]), 129, "portfolio array count", category)
    ids = set()
    for item in portfolio["projects"]:
        rec.check(item["id"] not in ids, f"portfolio unique {item['id']}", category)
        ids.add(item["id"])
        rec.check(bool(item["repo_name"]), f"portfolio repo {item['id']}", category)
        rec.check(bool(item["cluster"]), f"portfolio cluster {item['id']}", category)
        rec.check(bool(item["claimed_capability"]), f"portfolio capability {item['id']}", category)
        rec.check(bool(item["source_state"]), f"portfolio source state {item['id']}", category)
        rec.check(bool(item["integration_slots"]), f"portfolio slots {item['id']}", category)
    rec.equal(len(DIKWP_CHANNELS), 25, "25 directional channel catalog", category)
    rec.equal(len(set(DIKWP_CHANNELS)), 25, "channel uniqueness", category)


def compile_checks(service: Service) -> list[dict[str, Any]]:
    category = "bounded_compilation"
    expected = {
        "mission_assistive_with_appeal": "ADMISSIBLE",
        "mission_autonomous_denial": "BLOCKED",
        "mission_staged_transition": "ADMISSIBLE",
        "mission_rapid_without_floor": "KILLED",
        "mission_human_bounded_pilot": "ADMISSIBLE",
        "mission_autonomous_intensity": "KILLED",
        "mission_redacted_replication": "ADMISSIBLE",
        "mission_raw_export": "KILLED",
    }
    results = []
    for scenario in service.list_scenarios():
        for mission in scenario["missions"]:
            result = service.compile(scenario["id"], mission["id"], "qa", trials=80, seed=20260722, max_states=20000)
            results.append(result)
            capsule = result["capsule"]
            formal = capsule["formal"]
            mesh = capsule["mesh"]
            rec.equal(result["status"], expected[mission["id"]], f"expected status {mission['id']}", category)
            rec.check(result["semantic_stability"] in {"S4", "S3", "S2", "S1", "S0"}, f"semantic state {mission['id']}", category)
            rec.check(result["mesh_examination"] in {"M4", "M3", "M2", "M1", "M0"}, f"mesh state {mission['id']}", category)
            rec.check(result["evidence_reliability"] in {"Solid","Supported","Provisional","Borrowed","Hollow","Contested","Blocked"}, f"evidence state {mission['id']}", category)
            rec.check(len(result["capsule_hash"]) == 64, f"capsule hash {mission['id']}", category)
            rec.check(capsule["status_dimensions"]["no_scalar_without_explicit_weights"] is True, f"no scalar {mission['id']}", category)
            rec.check(capsule["authority_envelope"]["no_reality_authority_created"] is True, f"no authority {mission['id']}", category)
            rec.check(capsule["proof_carrying_certificate"]["external_validity_claimed"] is False, f"no external validity {mission['id']}", category)
            rec.equal(mesh["channel_catalog_count"], 25, f"mesh catalog {mission['id']}", category)
            rec.check(not mesh["invalid_channels"], f"valid mesh channels {mission['id']}", category)
            rec.check(mesh["active_channel_count"] > 0, f"active mesh {mission['id']}", category)
            rec.check(capsule["intent_conditioned_kernel"]["tested_node_count"] > 0, f"kernel tested {mission['id']}", category)
            rec.check(formal["proof_obligations"], f"proof obligations {mission['id']}", category)
            rec.check(formal["terminal_branch_count"] > 0, f"terminal branches {mission['id']}", category)
            rec.check(formal["plural_intent_surface"], f"purpose surface {mission['id']}", category)
            rec.check(formal["outcome_surface"], f"outcome surface {mission['id']}", category)
            if expected[mission["id"]] == "ADMISSIBLE":
                rec.equal(len(formal["counterexamples"]), 0, f"no counterexample {mission['id']}", category)
                rec.equal(result["semantic_stability"], "S4", f"stable admissible {mission['id']}", category)
            else:
                rec.check(len(formal["counterexamples"]) > 0, f"counterexamples {mission['id']}", category)
                for counterexample in formal["counterexamples"]:
                    rec.check(counterexample["trace_length"] >= 0, f"trace length {mission['id']}:{counterexample['property_id']}", category)
                    rec.check(bool(counterexample["reason"]), f"trace reason {mission['id']}:{counterexample['property_id']}", category)
    return results


def service_and_federation_checks(service: Service, results: list[dict[str, Any]]) -> None:
    category = "service_federation_settlement"
    counts = service.summary_counts()
    rec.equal(counts["portfolio_projects"], 129, "service portfolio count", category)
    rec.equal(counts["module_manifests"], 13, "service module count", category)
    rec.equal(counts["scenarios"], 4, "service scenario count", category)
    rec.equal(counts["compilations"], 8, "service compilation count", category)
    rec.check(service.login("admin", "mesh41-demo") is not None, "valid login", category)
    rec.check(service.login("admin", "wrongpass") is None, "invalid login", category)

    result = next(item for item in results if item["mission_id"] == "mission_assistive_with_appeal")
    package = service.export_bundle(result["id"], "qa")
    rec.check(package["bundle"]["authority_inherited"] is False, "export authority non-inheritance", category)
    rec.check(package["attestation"]["payload_hash"] == hashlib.sha256(canonical_json(package["bundle"]).encode()).hexdigest(), "export hash valid", category)
    imported = service.import_bundle(package, "qa")
    rec.check(imported["verification"]["valid"], "import verified", category)
    rec.check(imported["authority_inherited"] is False, "import authority non-inheritance", category)

    tampered = copy.deepcopy(package)
    tampered["bundle"]["compilation_id"] = "tampered"
    rec.check(not verify_evidence_bundle(tampered)["valid"], "tamper detected", category)

    restricted = copy.deepcopy(result)
    restricted["capsule"]["scenario"]["sensitivity"] = "restricted"
    redacted = export_evidence_bundle(restricted, node_id="node_test", shared_secret="secret")
    rec.check(verify_evidence_bundle(redacted, "secret")["valid"], "HMAC verified", category)
    rec.check(redacted["bundle"]["capsule"]["purpose_contracts"][0]["raw_expression"] == "[REDACTED]", "restricted purpose redacted", category)
    rec.check("terminal_states_preview" not in redacted["bundle"]["capsule"]["formal"], "restricted terminal states redacted", category)
    rec.check("branch_traces_preview" not in redacted["bundle"]["capsule"]["formal"], "restricted traces redacted", category)

    observed_state = result["capsule"]["formal"]["terminal_states_preview"][0]
    settlement = service.create_settlement(result["id"], {"observer": "qa_observer", "source_state": "locally_observed", "state": observed_state}, "qa")
    rec.check(bool(settlement["result"]["settlement_hash"]), "settlement hash", category)
    rec.check(settlement["result"]["authority_effect"] == "none", "settlement no authority", category)
    rec.check(service.list_settlements(result["id"]), "settlement persisted", category)

    record = service.get_scenario("scenario_civic_benefit_access")
    revised = copy.deepcopy(record["payload"])
    revised["title"] += " QA"
    updated = service.save_scenario(revised, "qa", expected_revision=record["revision"])
    rec.equal(updated["revision"], record["revision"] + 1, "optimistic revision update", category)
    conflict = False
    try:
        service.save_scenario(revised, "qa", expected_revision=record["revision"])
    except ConflictError:
        conflict = True
    rec.check(conflict, "stale revision rejected", category)
    rec.check(service.verify_audit()["valid"], "audit valid after writes", category)


def http_checks(db_path: Path) -> None:
    category = "http_end_to_end"
    port = 18822
    service = Service(ROOT, db_path)
    service.initialize()
    thread = threading.Thread(target=serve, args=(service, ROOT / "web", "127.0.0.1", port), daemon=True)
    thread.start()
    wait_port(port)

    status, health = http_json(port, "GET", "/api/health")
    rec.equal(status, 200, "health status", category)
    rec.equal(health.get("status"), "ok", "health body", category)
    status, unauthorized = http_json(port, "GET", "/api/scenarios")
    rec.equal(status, 401, "auth required", category)
    status, login = http_json(port, "POST", "/api/login", {"username": "admin", "password": "mesh41-demo"})
    rec.equal(status, 200, "login status", category)
    token = login.get("token")
    rec.check(bool(token), "login token", category)

    for path, key, expected_count in [
        ("/api/portfolio", "items", 129),
        ("/api/modules", "items", 13),
        ("/api/scenarios", "items", 4),
    ]:
        status, body = http_json(port, "GET", path, token=token)
        rec.equal(status, 200, f"GET {path}", category)
        rec.equal(len(body.get(key, [])), expected_count, f"count {path}", category)

    status, created = http_json(port, "POST", "/api/compile", {
        "scenario_id": "scenario_civic_benefit_access",
        "mission_id": "mission_assistive_with_appeal",
        "trials": 20,
        "seed": 7,
        "max_states": 5000,
    }, token)
    rec.equal(status, 201, "HTTP compile", category)
    rec.equal(created.get("status"), "ADMISSIBLE", "HTTP compile status", category)
    comp_id = created.get("id")
    status, fetched = http_json(port, "GET", f"/api/compilations/{comp_id}", token=token)
    rec.equal(status, 200, "HTTP compilation fetch", category)
    rec.equal(fetched.get("capsule_hash"), created.get("capsule_hash"), "HTTP compilation hash", category)

    status, package = http_json(port, "POST", f"/api/compilations/{comp_id}/export", {}, token)
    rec.equal(status, 200, "HTTP export", category)
    rec.check(package.get("bundle", {}).get("authority_inherited") is False, "HTTP export authority", category)
    status, imported = http_json(port, "POST", "/api/imports", {"package": package}, token)
    rec.equal(status, 201, "HTTP import", category)
    rec.check(imported.get("verification", {}).get("valid"), "HTTP import valid", category)

    observed = created["capsule"]["formal"]["terminal_states_preview"][0]
    status, settlement = http_json(port, "POST", "/api/settlements", {"compilation_id": comp_id, "observation": {"observer": "http_qa", "source_state": "locally_observed", "state": observed}}, token)
    rec.equal(status, 201, "HTTP settlement", category)
    rec.check(bool(settlement.get("result", {}).get("settlement_hash")), "HTTP settlement hash", category)

    status, audit = http_json(port, "GET", "/api/audit/verify", token=token)
    rec.equal(status, 200, "HTTP audit", category)
    rec.check(audit.get("valid"), "HTTP audit valid", category)

    conn = http.client.HTTPConnection("127.0.0.1", port, timeout=10)
    conn.request("GET", "/")
    response = conn.getresponse()
    html = response.read().decode("utf-8")
    headers = dict(response.getheaders())
    conn.close()
    rec.equal(response.status, 200, "web index", category)
    rec.check("HYPERWEAVE" in html, "web title", category)
    rec.check("Content-Security-Policy" in headers, "web CSP", category)


def unit_suite_checks() -> None:
    category = "unittest_suite"
    suite = unittest.defaultTestLoader.discover(str(ROOT / "tests"), pattern="test_core.py", top_level_dir=str(ROOT))
    result = unittest.TextTestRunner(stream=open(os.devnull, "w"), verbosity=0).run(suite)
    rec.equal(result.testsRun, 10, "unit test count", category)
    rec.equal(len(result.failures), 0, "unit test failures", category)
    rec.equal(len(result.errors), 0, "unit test errors", category)


def documentation_and_cleanliness_checks() -> None:
    category = "documentation_and_release"
    required = [
        "README.md", "LICENSE", "NOTICE", "SECURITY.md", "GOVERNANCE.md", "CITATION.cff",
        "Dockerfile", "docker-compose.yml", "openapi.yaml",
        *[f"docs/{name}" for name in [
            "00_public_portfolio_research.md", "01_intent_conditioned_gap_kernel.md", "02_system_architecture.md",
            "03_bounded_formal_model.md", "04_scenario_catalog.md", "05_portfolio_module_integration.md",
            "06_data_api_and_operations.md", "07_governance_and_nonclaims.md", "08_threat_model.md", "09_validation_plan.md",
        ]],
    ]
    for relative in required:
        path = ROOT / relative
        rec.check(path.is_file() and path.stat().st_size > 40, f"required file {relative}", category)
    readme = (ROOT / "README.md").read_text(encoding="utf-8")
    for token in ["python run.py serve", "127.0.0.1:8822", "mesh41-demo", "ADMISSIBLE", "authority_inherited"]:
        rec.check(token in readme, f"README token {token}", category)
    forbidden = []
    for path in ROOT.rglob("*"):
        if not path.is_file():
            continue
        rel = path.relative_to(ROOT).as_posix()
        if "__pycache__" in rel or path.suffix == ".pyc" or path.name.endswith((".sqlite3", ".sqlite3-wal", ".sqlite3-shm")):
            forbidden.append(rel)
    # The current development tree may contain caches before final cleanup; final package verifier repeats this check.
    rec.check(not [x for x in forbidden if not x.startswith("runtime/") and "__pycache__" not in x], "no unexpected database/cache artifacts", category, forbidden)


def main() -> int:
    started = time.time()
    static_checks()
    data_and_schema_checks()
    with tempfile.TemporaryDirectory() as temp:
        db_path = Path(temp) / "qa.sqlite3"
        service = Service(ROOT, db_path)
        seed_first = service.initialize()
        counts_first = service.summary_counts()
        seed_second = service.initialize()
        rec.check(seed_first["audit"]["valid"], "first seed audit", "service_federation_settlement")
        rec.check(seed_second["audit"]["valid"], "second seed audit", "service_federation_settlement")
        rec.equal(counts_first, service.summary_counts(), "seed idempotence", "service_federation_settlement")
        results = compile_checks(service)
        service_and_federation_checks(service, results)
        http_checks(Path(temp) / "http.sqlite3")
    unit_suite_checks()
    documentation_and_cleanliness_checks()

    summary = {
        "system_id": "dikwp-mesh-4.1-hyperweave-reality-compiler",
        "version": "1.0.0",
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "duration_seconds": round(time.time() - started, 3),
        "passed": rec.passed,
        "failed": rec.failed,
        "total": rec.passed + rec.failed,
        "categories": dict(rec.categories),
        "failures": rec.failures,
        "boundary": "QA verifies the local implementation and declared synthetic invariants. It does not validate external repositories, real-world causal completeness, action authority, author endorsement or field effectiveness.",
    }
    atomic_write_text(ROOT / "outputs" / "qa_summary.json", pretty_json(summary) + "\n")
    print(pretty_json(summary))
    return 0 if rec.failed == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
