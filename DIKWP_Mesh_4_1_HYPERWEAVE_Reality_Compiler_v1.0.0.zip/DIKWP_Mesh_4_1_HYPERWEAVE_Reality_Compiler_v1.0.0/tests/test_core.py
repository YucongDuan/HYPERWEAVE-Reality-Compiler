from __future__ import annotations

import copy
import json
import tempfile
import unittest
from pathlib import Path

from hyperweave.compiler import compile_reality_experiment
from hyperweave.constants import DIKWP_CHANNELS
from hyperweave.expressions import ExpressionError, eval_bool, eval_expression
from hyperweave.federation import export_evidence_bundle, verify_evidence_bundle
from hyperweave.service import ConflictError, Service
from hyperweave.settlement import settle_observation
from hyperweave.simulation import simulate_mission
from hyperweave.validation import validate_scenario


ROOT = Path(__file__).resolve().parents[1]


class ExpressionTests(unittest.TestCase):
    def test_arithmetic_and_boolean(self) -> None:
        state = {"x": 4, "y": 2, "flag": True}
        self.assertEqual(eval_expression("x + y * 3", state), 10)
        self.assertTrue(eval_bool("flag and x >= y", state))

    def test_unsafe_syntax_is_rejected(self) -> None:
        for expression in ("__import__('os')", "x.__class__", "open('/tmp/x')", "[x for x in [1]]"):
            with self.subTest(expression=expression):
                with self.assertRaises(ExpressionError):
                    eval_expression(expression, {"x": 1})


class ScenarioTests(unittest.TestCase):
    def test_all_scenarios_validate(self) -> None:
        for path in sorted((ROOT / "data" / "scenarios").glob("*.json")):
            with self.subTest(path=path.name):
                payload = json.loads(path.read_text(encoding="utf-8"))
                self.assertEqual(validate_scenario(payload)["id"], payload["id"])

    def test_dikwp_catalog_is_complete(self) -> None:
        self.assertEqual(len(DIKWP_CHANNELS), 25)
        self.assertEqual(len(set(DIKWP_CHANNELS)), 25)
        self.assertIn("D→P", DIKWP_CHANNELS)
        self.assertIn("P→D", DIKWP_CHANNELS)


class CompilerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.temp = tempfile.TemporaryDirectory()
        cls.service = Service(ROOT, Path(cls.temp.name) / "test.sqlite3")
        cls.service.initialize()

    @classmethod
    def tearDownClass(cls) -> None:
        cls.temp.cleanup()

    def test_expected_mission_statuses(self) -> None:
        expected = {
            "mission_assistive_with_appeal": "ADMISSIBLE",
            "mission_autonomous_denial": "BLOCKED",
            "mission_staged_transition": "ADMISSIBLE",
            "mission_rapid_without_floor": "KILLED",
            "mission_human_bounded_pilot": "ADMISSIBLE",
            "mission_autonomous_intensity": "KILLED",
            "mission_redacted_replication": "ADMISSIBLE",
            "mission_raw_export": "KILLED",
        }
        for scenario in self.service.list_scenarios():
            for mission in scenario["missions"]:
                with self.subTest(mission=mission["id"]):
                    result = self.service.compile(scenario["id"], mission["id"], "unit", trials=20, max_states=5000)
                    self.assertEqual(result["status"], expected[mission["id"]])
                    self.assertTrue(result["capsule_hash"])
                    self.assertTrue(result["capsule"]["status_dimensions"]["no_scalar_without_explicit_weights"])
                    self.assertFalse(result["capsule"]["authority_envelope"]["no_reality_authority_created"] is False)

    def test_deterministic_sampling(self) -> None:
        record = self.service.get_scenario("scenario_civic_benefit_access")
        scenario = record["payload"]
        mission = next(m for m in scenario["missions"] if m["id"] == "mission_assistive_with_appeal")
        first = simulate_mission(scenario, mission, trials=50, seed=7)
        second = simulate_mission(scenario, mission, trials=50, seed=7)
        self.assertEqual(first, second)

    def test_kernel_and_mesh(self) -> None:
        result = self.service.compile("scenario_civic_benefit_access", "mission_assistive_with_appeal", "unit", trials=10, max_states=5000)
        capsule = result["capsule"]
        self.assertGreater(capsule["intent_conditioned_kernel"]["critical_node_count"], 0)
        self.assertEqual(capsule["mesh"]["channel_catalog_count"], 25)
        self.assertFalse(capsule["mesh"]["invalid_channels"])
        self.assertGreater(capsule["mesh"]["active_channel_count"], 0)

    def test_restricted_export_redacts(self) -> None:
        result = self.service.compile("scenario_civic_benefit_access", "mission_assistive_with_appeal", "unit", trials=10, max_states=5000)
        restricted = copy.deepcopy(result)
        restricted["capsule"]["scenario"]["sensitivity"] = "restricted"
        package = export_evidence_bundle(restricted, node_id="node_test", shared_secret="secret")
        self.assertTrue(verify_evidence_bundle(package, "secret")["valid"])
        self.assertFalse(package["bundle"]["authority_inherited"])
        self.assertEqual(package["bundle"]["capsule"]["purpose_contracts"][0]["raw_expression"], "[REDACTED]")
        self.assertNotIn("terminal_states_preview", package["bundle"]["capsule"]["formal"])

    def test_settlement_and_unknown_variable(self) -> None:
        compilation = self.service.compile("scenario_civic_benefit_access", "mission_assistive_with_appeal", "unit", trials=10, max_states=5000)
        record = self.service.get_scenario(compilation["scenario_id"])
        scenario = record["payload"]
        mission = next(m for m in scenario["missions"] if m["id"] == compilation["mission_id"])
        observation = {
            "observer": "independent_observer",
            "source_state": "locally_observed",
            "state": compilation["capsule"]["formal"]["terminal_states_preview"][0],
        }
        settled = settle_observation(scenario, mission, compilation, observation)
        self.assertIn(settled["settlement_state"], {"settled_within_declared_contract", "open", "contested"})
        bad = copy.deepcopy(observation)
        bad["state"]["unknown_variable"] = 1
        with self.assertRaises(ValueError):
            settle_observation(scenario, mission, compilation, bad)


class PersistenceTests(unittest.TestCase):
    def test_seed_idempotence_login_revision_and_audit(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            service = Service(ROOT, Path(temp) / "runtime.sqlite3")
            first = service.initialize()
            counts_first = service.summary_counts()
            second = service.initialize()
            counts_second = service.summary_counts()
            self.assertEqual(counts_first, counts_second)
            self.assertTrue(first["audit"]["valid"])
            self.assertTrue(second["audit"]["valid"])
            self.assertIsNotNone(service.login("admin", "mesh41-demo"))
            self.assertIsNone(service.login("admin", "wrongpass"))

            record = service.get_scenario("scenario_civic_benefit_access")
            payload = copy.deepcopy(record["payload"])
            payload["title"] += "（修订测试）"
            updated = service.save_scenario(payload, "admin", expected_revision=record["revision"])
            self.assertEqual(updated["revision"], record["revision"] + 1)
            with self.assertRaises(ConflictError):
                service.save_scenario(payload, "admin", expected_revision=record["revision"])
            self.assertTrue(service.verify_audit()["valid"])


if __name__ == "__main__":
    unittest.main()
