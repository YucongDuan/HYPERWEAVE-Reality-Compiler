from __future__ import annotations

SYSTEM_ID = "dikwp-mesh-4.1-hyperweave-reality-compiler"
SYSTEM_NAME = "DIKWP-Mesh 4.1 HYPERWEAVE Reality Compiler"
SYSTEM_NAME_ZH = "DIKWP-Mesh 4.1 HYPERWEAVE 多意图因果世界线、形式反例与证明携带现实实验系统"
VERSION = "1.0.0"
DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 8822
DEFAULT_DB = "runtime/hyperweave.sqlite3"
DEFAULT_DEMO_PASSWORD = "mesh41-demo"

DIKWP_ROLES = ("D", "I", "K", "W", "P")
DIKWP_CHANNELS = tuple(f"{src}→{dst}" for src in DIKWP_ROLES for dst in DIKWP_ROLES)

CLOSURE_STATES = (
    "ADMISSIBLE",
    "UNSETTLED",
    "CONTESTED",
    "BLOCKED",
    "KILLED",
)
SEMANTIC_STABILITY = ("S4", "S3", "S2", "S1", "S0")
MESH_EXAMINATION = ("M4", "M3", "M2", "M1", "M0")
EVIDENCE_RELIABILITY = (
    "Solid",
    "Supported",
    "Provisional",
    "Borrowed",
    "Hollow",
    "Contested",
    "Blocked",
)

DEMO_USERS = (
    ("admin", "系统管理员", "system_admin"),
    ("compiler", "现实实验编译角色", "mission_compiler"),
    ("auditor", "形式验证与证据审计角色", "assurance_auditor"),
    ("settler", "现实观察与结算角色", "outcome_settler"),
    ("affected", "受影响方代理角色", "affected_party_proxy"),
    ("federation", "联邦节点交换角色", "federation_operator"),
)

WRITE_ROLES = {
    "system_admin",
    "mission_compiler",
    "assurance_auditor",
    "outcome_settler",
    "federation_operator",
}

PROJECT_BOUNDARY = (
    "HYPERWEAVE、Reality Compiler、世界线与现实实验均为工程句柄；系统不为“现实”“世界”“未来”或任何外部概念生成普遍定义。"
    "系统只在带来源、观察者、时间、范围、约束和意图的有限状态模型中进行编译、反例搜索与结算。"
)
