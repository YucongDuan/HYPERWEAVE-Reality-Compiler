from __future__ import annotations

import json
import mimetypes
import urllib.parse
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

from .constants import WRITE_ROLES
from .service import ConflictError, Service
from .util import ensure_relative_path

MAX_BODY = 5 * 1024 * 1024


class AppHandler(BaseHTTPRequestHandler):
    service: Service
    web_root: Path

    server_version = "HyperweaveHTTP/1.0"

    def log_message(self, format: str, *args: Any) -> None:
        print(f"[http] {self.address_string()} - {format % args}")

    def _headers(self, status: int, content_type: str = "application/json; charset=utf-8", length: int | None = None) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
        self.send_header("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        if length is not None:
            self.send_header("Content-Length", str(length))
        self.end_headers()

    def _json(self, value: Any, status: int = 200) -> None:
        payload = json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2).encode("utf-8")
        self._headers(status, length=len(payload))
        self.wfile.write(payload)

    def _error(self, status: int, message: str, *, details: Any = None) -> None:
        body = {"error": message, "status": status}
        if details is not None:
            body["details"] = details
        self._json(body, status)

    def _body(self) -> dict[str, Any]:
        raw_length = self.headers.get("Content-Length", "0")
        try:
            length = int(raw_length)
        except ValueError as exc:
            raise ValueError("invalid Content-Length") from exc
        if length < 0 or length > MAX_BODY:
            raise ValueError("request body exceeds 5 MB")
        data = self.rfile.read(length) if length else b"{}"
        try:
            value = json.loads(data.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValueError("request body must be UTF-8 JSON") from exc
        if not isinstance(value, dict):
            raise ValueError("request JSON root must be an object")
        return value

    def _token(self) -> str:
        auth = self.headers.get("Authorization", "")
        if auth.startswith("Bearer "):
            return auth[7:].strip()
        return ""

    def _user(self, *, required: bool = True) -> dict[str, Any] | None:
        user = self.service.authenticate(self._token())
        if required and not user:
            self._error(HTTPStatus.UNAUTHORIZED, "authentication required")
            return None
        return user

    def _require_write(self, user: dict[str, Any] | None) -> bool:
        if not user or user.get("role") not in WRITE_ROLES:
            self._error(HTTPStatus.FORBIDDEN, "workflow role is not permitted to write")
            return False
        return True

    def do_OPTIONS(self) -> None:  # noqa: N802
        self._headers(HTTPStatus.NO_CONTENT, length=0)

    def do_GET(self) -> None:  # noqa: N802
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        query = urllib.parse.parse_qs(parsed.query)
        try:
            if path == "/api/health":
                self._json(self.service.health())
                return
            if path.startswith("/api/"):
                user = self._user()
                if not user:
                    return
                if path == "/api/me":
                    self._json(user)
                elif path == "/api/portfolio":
                    self._json(self.service.portfolio(cluster=(query.get("cluster") or [None])[0], query=(query.get("q") or [None])[0]))
                elif path == "/api/modules":
                    self._json({"items": self.service.list_modules()})
                elif path == "/api/scenarios":
                    self._json({"items": self.service.list_scenarios()})
                elif path.startswith("/api/scenarios/"):
                    self._json(self.service.get_scenario(path.rsplit("/", 1)[1]))
                elif path == "/api/compilations":
                    scenario_id = (query.get("scenario_id") or [None])[0]
                    limit = min(500, max(1, int((query.get("limit") or [100])[0])))
                    self._json({"items": self.service.list_compilations(scenario_id, limit)})
                elif path.startswith("/api/compilations/"):
                    self._json(self.service.get_compilation(path.rsplit("/", 1)[1]))
                elif path == "/api/settlements":
                    compilation_id = (query.get("compilation_id") or [None])[0]
                    self._json({"items": self.service.list_settlements(compilation_id)})
                elif path == "/api/audit":
                    limit = min(1000, max(1, int((query.get("limit") or [200])[0])))
                    self._json({"items": self.service.list_audit(limit)})
                elif path == "/api/audit/verify":
                    self._json(self.service.verify_audit())
                else:
                    self._error(HTTPStatus.NOT_FOUND, "API endpoint not found")
                return
            self._serve_static(path)
        except KeyError as exc:
            self._error(HTTPStatus.NOT_FOUND, str(exc))
        except ValueError as exc:
            self._error(HTTPStatus.BAD_REQUEST, str(exc))
        except Exception as exc:  # pragma: no cover - final boundary
            self._error(HTTPStatus.INTERNAL_SERVER_ERROR, "server error", details=str(exc))

    def do_POST(self) -> None:  # noqa: N802
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        try:
            body = self._body()
            if path == "/api/login":
                result = self.service.login(str(body.get("username", "")), str(body.get("password", "")))
                if not result:
                    self._error(HTTPStatus.UNAUTHORIZED, "invalid credentials")
                else:
                    self._json(result)
                return
            user = self._user()
            if not user:
                return
            if path == "/api/scenarios":
                if not self._require_write(user):
                    return
                self._json(self.service.save_scenario(body["scenario"], user["username"], body.get("expected_revision")), HTTPStatus.CREATED)
            elif path == "/api/compile":
                if not self._require_write(user):
                    return
                result = self.service.compile(
                    str(body.get("scenario_id", "")),
                    str(body.get("mission_id", "")),
                    user["username"],
                    trials=int(body.get("trials", 1000)),
                    seed=int(body.get("seed", 20260722)),
                    max_states=int(body.get("max_states", 20000)),
                )
                self._json(result, HTTPStatus.CREATED)
            elif path == "/api/settlements":
                if not self._require_write(user):
                    return
                result = self.service.create_settlement(str(body.get("compilation_id", "")), body.get("observation", {}), user["username"])
                self._json(result, HTTPStatus.CREATED)
            elif path.startswith("/api/compilations/") and path.endswith("/export"):
                if not self._require_write(user):
                    return
                compilation_id = path.split("/")[3]
                self._json(self.service.export_bundle(compilation_id, user["username"]))
            elif path == "/api/imports":
                if not self._require_write(user):
                    return
                self._json(self.service.import_bundle(body.get("package", {}), user["username"], body.get("shared_secret")), HTTPStatus.CREATED)
            else:
                self._error(HTTPStatus.NOT_FOUND, "API endpoint not found")
        except ConflictError as exc:
            self._error(HTTPStatus.CONFLICT, str(exc))
        except KeyError as exc:
            self._error(HTTPStatus.NOT_FOUND, str(exc))
        except (ValueError, TypeError) as exc:
            self._error(HTTPStatus.BAD_REQUEST, str(exc))
        except Exception as exc:  # pragma: no cover
            self._error(HTTPStatus.INTERNAL_SERVER_ERROR, "server error", details=str(exc))

    def _serve_static(self, path: str) -> None:
        if path in {"", "/"}:
            target = self.web_root / "index.html"
        else:
            target = self.web_root / path.lstrip("/")
        try:
            target = ensure_relative_path(self.web_root, target)
        except ValueError:
            self._error(HTTPStatus.FORBIDDEN, "invalid path")
            return
        if not target.is_file():
            self._error(HTTPStatus.NOT_FOUND, "file not found")
            return
        data = target.read_bytes()
        content_type = mimetypes.guess_type(str(target))[0] or "application/octet-stream"
        if content_type.startswith("text/") or content_type in {"application/javascript", "application/json"}:
            content_type += "; charset=utf-8"
        self._headers(HTTPStatus.OK, content_type, len(data))
        self.wfile.write(data)


def serve(service: Service, web_root: str | Path, host: str, port: int) -> None:
    handler = type("HyperweaveHandler", (AppHandler,), {"service": service, "web_root": Path(web_root).resolve()})
    httpd = ThreadingHTTPServer((host, port), handler)
    print(f"HYPERWEAVE listening on http://{host}:{port}")
    print("Press Ctrl+C to stop.")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()
