from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .compiler import compile_reality_experiment
from .constants import PROJECT_BOUNDARY, SYSTEM_ID, SYSTEM_NAME, VERSION
from .db import Database
from .federation import export_evidence_bundle, verify_evidence_bundle
from .seed import seed_project
from .settlement import settle_observation
from .util import canonical_json, make_id, sha256_text, utc_now
from .validation import validate_scenario


class ConflictError(RuntimeError):
    pass


class Service:
    def __init__(self, root: str | Path, db_path: str | Path):
        self.root = Path(root).resolve()
        self.db = Database(db_path)
        self.db.initialize()

    def initialize(self) -> dict[str, Any]:
        seeded = seed_project(self.db, self.root)
        return {"seeded": seeded, "audit": self.db.verify_audit()}

    def summary_counts(self) -> dict[str, int]:
        tables = [
            "portfolio_projects",
            "module_manifests",
            "scenarios",
            "compilations",
            "settlements",
            "nodes",
            "evidence_imports",
            "audit_events",
        ]
        result: dict[str, int] = {}
        with self.db.connect() as conn:
            for table in tables:
                result[table] = int(conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0])
        return result

    def health(self) -> dict[str, Any]:
        return {
            "status": "ok",
            "system_id": SYSTEM_ID,
            "system_name": SYSTEM_NAME,
            "version": VERSION,
            "database": str(self.db.path),
            "counts": self.summary_counts(),
            "audit": self.db.verify_audit(),
            "boundary": PROJECT_BOUNDARY,
            "network_default": "disabled",
            "external_model_default": "disabled",
        }

    def login(self, username: str, password: str) -> dict[str, Any] | None:
        return self.db.login(username, password)

    def authenticate(self, token: str) -> dict[str, Any] | None:
        return self.db.authenticate(token)

    def portfolio(self, cluster: str | None = None, query: str | None = None) -> dict[str, Any]:
        clauses: list[str] = []
        params: list[Any] = []
        if cluster:
            clauses.append("cluster=?")
            params.append(cluster)
        if query:
            clauses.append("(repo_name LIKE ? OR claimed_capability LIKE ? OR integration_slots_json LIKE ?)")
            token = f"%{query}%"
            params.extend([token, token, token])
        where = " WHERE " + " AND ".join(clauses) if clauses else ""
        rows = self.db.query_all(f"SELECT * FROM portfolio_projects{where} ORDER BY cluster,repo_name", tuple(params))
        for row in rows:
            row["integration_slots"] = json.loads(row.pop("integration_slots_json"))
        clusters: dict[str, int] = {}
        for row in rows:
            clusters[row["cluster"]] = clusters.get(row["cluster"], 0) + 1
        meta = {}
        snapshot_path = self.root / "data" / "portfolio_snapshot.json"
        if snapshot_path.exists():
            snapshot = json.loads(snapshot_path.read_text(encoding="utf-8"))
            meta = {key: snapshot.get(key) for key in ("snapshot_id", "observed_repository_total", "observed_starred_total", "curated_project_count", "method")}
        return {"meta": meta, "clusters": clusters, "items": rows}

    def list_modules(self) -> list[dict[str, Any]]:
        rows = self.db.query_all("SELECT payload_json,payload_hash FROM module_manifests ORDER BY id")
        result = []
        for row in rows:
            payload = json.loads(row["payload_json"])
            payload["manifest_hash"] = row["payload_hash"]
            result.append(payload)
        return result

    def list_scenarios(self) -> list[dict[str, Any]]:
        rows = self.db.query_all("SELECT id,title,domain,source_state,sensitivity,revision,payload_hash,created_at,updated_at,payload_json FROM scenarios ORDER BY title")
        result = []
        for row in rows:
            payload = json.loads(row.pop("payload_json"))
            row["mission_count"] = len(payload.get("missions", []))
            row["missions"] = [
                {
                    "id": mission["id"],
                    "title": mission["title"],
                    "source_state": mission.get("source_state"),
                    "sequence_length": len(mission.get("sequence", [])),
                    "module_pipeline": mission.get("module_pipeline", []),
                }
                for mission in payload.get("missions", [])
            ]
            result.append(row)
        return result

    def get_scenario(self, scenario_id: str) -> dict[str, Any]:
        row = self.db.query_one("SELECT * FROM scenarios WHERE id=?", (scenario_id,))
        if not row:
            raise KeyError(f"scenario not found: {scenario_id}")
        return {
            "id": row["id"],
            "title": row["title"],
            "domain": row["domain"],
            "source_state": row["source_state"],
            "sensitivity": row["sensitivity"],
            "revision": row["revision"],
            "payload_hash": row["payload_hash"],
            "created_at": row["created_at"],
            "updated_at": row["updated_at"],
            "payload": json.loads(row["payload_json"]),
        }

    def save_scenario(self, payload: dict[str, Any], actor: str, expected_revision: int | None = None) -> dict[str, Any]:
        scenario = validate_scenario(payload)
        payload_json = canonical_json(scenario)
        payload_hash = sha256_text(payload_json)
        now = utc_now()
        existing = self.db.query_one("SELECT * FROM scenarios WHERE id=?", (scenario["id"],))
        with self.db.transaction() as conn:
            if existing:
                if expected_revision is None or int(expected_revision) != int(existing["revision"]):
                    raise ConflictError(f"scenario revision conflict: expected {expected_revision}, current {existing['revision']}")
                revision = int(existing["revision"]) + 1
                cursor = conn.execute(
                    """UPDATE scenarios SET title=?,domain=?,source_state=?,sensitivity=?,revision=?,payload_json=?,payload_hash=?,updated_at=?
                       WHERE id=? AND revision=?""",
                    (
                        scenario["title"],
                        scenario["domain"],
                        scenario["source_state"],
                        scenario.get("sensitivity", "public_synthetic"),
                        revision,
                        payload_json,
                        payload_hash,
                        now,
                        scenario["id"],
                        existing["revision"],
                    ),
                )
                if cursor.rowcount != 1:
                    raise ConflictError("scenario was modified concurrently")
                action = "update_scenario"
            else:
                revision = 1
                conn.execute(
                    """INSERT INTO scenarios(id,title,domain,source_state,sensitivity,revision,payload_json,payload_hash,created_at,updated_at)
                       VALUES (?,?,?,?,?,?,?,?,?,?)""",
                    (
                        scenario["id"], scenario["title"], scenario["domain"], scenario["source_state"],
                        scenario.get("sensitivity", "public_synthetic"), revision, payload_json, payload_hash, now, now,
                    ),
                )
                action = "create_scenario"
            self.db.append_audit(conn, actor, action, "scenario", scenario["id"], {"revision": revision, "payload_hash": payload_hash})
        return self.get_scenario(scenario["id"])

    def compile(
        self,
        scenario_id: str,
        mission_id: str,
        actor: str,
        *,
        trials: int = 1000,
        seed: int = 20260722,
        max_states: int = 20000,
    ) -> dict[str, Any]:
        scenario_record = self.get_scenario(scenario_id)
        compilation = compile_reality_experiment(
            scenario_record,
            mission_id,
            self.list_modules(),
            actor=actor,
            trials=trials,
            seed=seed,
            max_states=max_states,
        )
        with self.db.transaction() as conn:
            conn.execute(
                """INSERT INTO compilations(
                    id,scenario_id,scenario_revision,mission_id,status,semantic_stability,mesh_examination,evidence_reliability,
                    seed,trials,capsule_json,capsule_hash,created_by,created_at
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    compilation["id"], compilation["scenario_id"], compilation["scenario_revision"], compilation["mission_id"],
                    compilation["status"], compilation["semantic_stability"], compilation["mesh_examination"], compilation["evidence_reliability"],
                    compilation["seed"], compilation["trials"], canonical_json(compilation["capsule"]), compilation["capsule_hash"], actor, compilation["created_at"],
                ),
            )
            self.db.append_audit(
                conn,
                actor,
                "compile_reality_experiment",
                "compilation",
                compilation["id"],
                {
                    "scenario_id": scenario_id,
                    "mission_id": mission_id,
                    "status": compilation["status"],
                    "capsule_hash": compilation["capsule_hash"],
                },
            )
        return compilation

    def list_compilations(self, scenario_id: str | None = None, limit: int = 100) -> list[dict[str, Any]]:
        if scenario_id:
            rows = self.db.query_all(
                "SELECT id,scenario_id,scenario_revision,mission_id,status,semantic_stability,mesh_examination,evidence_reliability,seed,trials,capsule_hash,created_by,created_at FROM compilations WHERE scenario_id=? ORDER BY created_at DESC LIMIT ?",
                (scenario_id, limit),
            )
        else:
            rows = self.db.query_all(
                "SELECT id,scenario_id,scenario_revision,mission_id,status,semantic_stability,mesh_examination,evidence_reliability,seed,trials,capsule_hash,created_by,created_at FROM compilations ORDER BY created_at DESC LIMIT ?",
                (limit,),
            )
        return rows

    def get_compilation(self, compilation_id: str) -> dict[str, Any]:
        row = self.db.query_one("SELECT * FROM compilations WHERE id=?", (compilation_id,))
        if not row:
            raise KeyError(f"compilation not found: {compilation_id}")
        return {
            "id": row["id"],
            "scenario_id": row["scenario_id"],
            "scenario_revision": row["scenario_revision"],
            "mission_id": row["mission_id"],
            "status": row["status"],
            "semantic_stability": row["semantic_stability"],
            "mesh_examination": row["mesh_examination"],
            "evidence_reliability": row["evidence_reliability"],
            "seed": row["seed"],
            "trials": row["trials"],
            "capsule": json.loads(row["capsule_json"]),
            "capsule_hash": row["capsule_hash"],
            "created_by": row["created_by"],
            "created_at": row["created_at"],
        }

    def create_settlement(self, compilation_id: str, observation: dict[str, Any], actor: str) -> dict[str, Any]:
        compilation = self.get_compilation(compilation_id)
        scenario_record = self.get_scenario(compilation["scenario_id"])
        scenario = scenario_record["payload"]
        mission = next(item for item in scenario["missions"] if item["id"] == compilation["mission_id"])
        result = settle_observation(scenario, mission, compilation, observation)
        settlement_id = make_id("settlement")
        created_at = utc_now()
        with self.db.transaction() as conn:
            conn.execute(
                """INSERT INTO settlements(id,compilation_id,status,observation_json,result_json,result_hash,created_by,created_at)
                   VALUES (?,?,?,?,?,?,?,?)""",
                (
                    settlement_id,
                    compilation_id,
                    result["settlement_state"],
                    canonical_json(observation),
                    canonical_json(result),
                    result["settlement_hash"],
                    actor,
                    created_at,
                ),
            )
            self.db.append_audit(conn, actor, "record_settlement", "settlement", settlement_id, {"compilation_id": compilation_id, "status": result["settlement_state"], "result_hash": result["settlement_hash"]})
        return {"id": settlement_id, "compilation_id": compilation_id, "status": result["settlement_state"], "observation": observation, "result": result, "created_by": actor, "created_at": created_at}

    def list_settlements(self, compilation_id: str | None = None) -> list[dict[str, Any]]:
        if compilation_id:
            rows = self.db.query_all("SELECT * FROM settlements WHERE compilation_id=? ORDER BY created_at DESC", (compilation_id,))
        else:
            rows = self.db.query_all("SELECT * FROM settlements ORDER BY created_at DESC LIMIT 100")
        result = []
        for row in rows:
            result.append({
                "id": row["id"], "compilation_id": row["compilation_id"], "status": row["status"],
                "observation": json.loads(row["observation_json"]), "result": json.loads(row["result_json"]),
                "result_hash": row["result_hash"], "created_by": row["created_by"], "created_at": row["created_at"],
            })
        return result

    def _local_node(self) -> dict[str, Any]:
        meta = self.db.query_one("SELECT value FROM meta WHERE key='local_node_id'")
        node_id = meta["value"] if meta else "node_cn_shanghai_demo"
        node = self.db.query_one("SELECT * FROM nodes WHERE id=?", (node_id,))
        if not node:
            raise RuntimeError("local node is not configured")
        return node

    def export_bundle(self, compilation_id: str, actor: str) -> dict[str, Any]:
        compilation = self.get_compilation(compilation_id)
        node = self._local_node()
        package = export_evidence_bundle(compilation, node_id=node["id"], shared_secret=node.get("shared_secret"))
        with self.db.transaction() as conn:
            self.db.append_audit(conn, actor, "export_evidence_bundle", "compilation", compilation_id, {"bundle_id": package["bundle"]["id"], "payload_hash": package["attestation"]["payload_hash"]})
        return package

    def import_bundle(self, package: dict[str, Any], actor: str, shared_secret: str | None = None) -> dict[str, Any]:
        bundle = package.get("bundle", {})
        # A locally exported demo bundle can be verified against the matching local node secret.
        # This convenience does not transfer authority and is not a replacement for institutional PKI.
        if shared_secret is None and isinstance(bundle, dict) and bundle.get("source_node_id"):
            node = self.db.query_one("SELECT shared_secret FROM nodes WHERE id=?", (bundle.get("source_node_id"),))
            if node:
                shared_secret = node.get("shared_secret")
        verification = verify_evidence_bundle(package, shared_secret=shared_secret)
        import_id = make_id("import")
        status = "verified_integrity" if verification["valid"] else "rejected_integrity"
        with self.db.transaction() as conn:
            conn.execute(
                """INSERT INTO evidence_imports(id,bundle_id,source_node_id,status,authority_inherited,verification_json,package_json,imported_by,created_at)
                   VALUES (?,?,?,?,?,?,?,?,?)""",
                (
                    import_id,
                    bundle.get("id", "unknown"),
                    bundle.get("source_node_id"),
                    status,
                    0,
                    canonical_json(verification),
                    canonical_json(package),
                    actor,
                    utc_now(),
                ),
            )
            self.db.append_audit(conn, actor, "import_evidence_bundle", "evidence_import", import_id, {"status": status, "authority_inherited": False})
        return {"id": import_id, "status": status, "verification": verification, "authority_inherited": False}

    def list_audit(self, limit: int = 200) -> list[dict[str, Any]]:
        return self.db.query_all("SELECT * FROM audit_events ORDER BY seq DESC LIMIT ?", (limit,))

    def verify_audit(self) -> dict[str, Any]:
        return self.db.verify_audit()
