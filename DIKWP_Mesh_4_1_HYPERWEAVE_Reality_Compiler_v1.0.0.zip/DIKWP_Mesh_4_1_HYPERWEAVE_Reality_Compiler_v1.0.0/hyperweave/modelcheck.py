from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from typing import Any, Iterable

from .expressions import ExpressionError, eval_bool, eval_expression
from .util import canonical_json, clamp, deep_copy_json, sha256_text


@dataclass
class Branch:
    state: dict[str, Any]
    trace: list[dict[str, Any]]
    terminated: bool = False
    termination_reason: str | None = None


def variable_specs(scenario: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {item["id"]: item for item in scenario["state_variables"]}


def initial_state(scenario: dict[str, Any]) -> dict[str, Any]:
    return {item["id"]: deep_copy_json(item["initial"]) for item in scenario["state_variables"]}


def _coerce_value(value: Any, spec: dict[str, Any]) -> Any:
    vtype = spec["type"]
    if vtype == "boolean":
        return bool(value)
    if vtype == "integer":
        if isinstance(value, bool):
            raise ExpressionError(f"boolean cannot update integer {spec['id']}")
        numeric = int(round(float(value)))
        return int(clamp(numeric, spec.get("min"), spec.get("max")))
    if vtype == "number":
        if isinstance(value, bool):
            raise ExpressionError(f"boolean cannot update number {spec['id']}")
        numeric = float(value)
        bounded = clamp(numeric, spec.get("min"), spec.get("max"))
        return round(bounded, int(spec.get("precision", 6)))
    if vtype == "string":
        return str(value)
    raise ExpressionError(f"unsupported state type: {vtype}")


def apply_action(
    state: dict[str, Any],
    action: dict[str, Any],
    specs: dict[str, dict[str, Any]],
) -> list[dict[str, Any]]:
    if not eval_bool(action.get("precondition", "True"), state):
        return []
    results: list[dict[str, Any]] = []
    total_weight = sum(float(effect.get("weight", 1.0)) for effect in action["effects"])
    for effect in action["effects"]:
        next_state = dict(state)
        updates: dict[str, Any] = {}
        # Updates are evaluated against the pre-action state so an effect is simultaneous.
        for variable_id, expression in effect["updates"].items():
            raw_value = eval_expression(expression, state) if isinstance(expression, str) else expression
            value = _coerce_value(raw_value, specs[variable_id])
            next_state[variable_id] = value
            updates[variable_id] = value
        results.append(
            {
                "effect_id": effect["id"],
                "weight": float(effect.get("weight", 1.0)) / total_weight,
                "state": next_state,
                "updates": updates,
                "note": effect.get("note", ""),
            }
        )
    return results


def _trace_snapshot(trace: list[dict[str, Any]], max_items: int = 64) -> list[dict[str, Any]]:
    return deep_copy_json(trace[-max_items:])


def _record_counterexample(
    storage: dict[str, dict[str, Any]],
    property_id: str,
    gate: str,
    reason: str,
    trace: list[dict[str, Any]],
    state: dict[str, Any],
) -> None:
    candidate = {
        "property_id": property_id,
        "gate": gate,
        "reason": reason,
        "trace_length": max(0, len(trace) - 1),
        "trace": _trace_snapshot(trace),
        "terminal_state": deep_copy_json(state),
    }
    existing = storage.get(property_id)
    if existing is None or candidate["trace_length"] < existing["trace_length"]:
        storage[property_id] = candidate


def _evaluate_invariants(
    invariants: list[dict[str, Any]],
    state: dict[str, Any],
) -> list[dict[str, Any]]:
    results = []
    for invariant in invariants:
        try:
            passed = eval_bool(invariant["expression"], state)
            error = None
        except ExpressionError as exc:
            passed = False
            error = str(exc)
        results.append(
            {
                "id": invariant["id"],
                "passed": passed,
                "gate": invariant.get("gate", "BLOCK"),
                "description": invariant.get("description", invariant["id"]),
                "expression": invariant["expression"],
                "source_state": invariant.get("source_state"),
                "error": error,
            }
        )
    return results


def _stop_reason(mission: dict[str, Any], state: dict[str, Any]) -> str | None:
    for stop in mission.get("stop_conditions", []):
        if eval_bool(stop["expression"], state):
            return stop["id"]
    return None


def _purpose_surface(
    scenario: dict[str, Any],
    mission: dict[str, Any],
    terminal_states: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    purpose_lookup = {p["id"]: p for p in scenario["purposes"]}
    surface = []
    for purpose_id in mission["purpose_ids"]:
        purpose = purpose_lookup[purpose_id]
        branch_states: list[str] = []
        details: list[dict[str, Any]] = []
        for state in terminal_states:
            acceptance = [eval_bool(item["expression"], state) for item in purpose.get("acceptance", [])]
            veto = [eval_bool(item["expression"], state) for item in purpose.get("veto", [])]
            if any(veto):
                branch_state = "veto_triggered"
            elif acceptance and all(acceptance):
                branch_state = "satisfied"
            elif not acceptance:
                branch_state = "unresolved"
            else:
                branch_state = "unmet"
            branch_states.append(branch_state)
            details.append({"state": branch_state, "acceptance": acceptance, "veto": veto})
        unique = sorted(set(branch_states))
        if unique == ["satisfied"]:
            aggregate = "satisfied"
        elif "veto_triggered" in unique:
            aggregate = "veto_triggered"
        elif len(unique) > 1:
            aggregate = "contested_across_branches"
        elif unique:
            aggregate = unique[0]
        else:
            aggregate = "unresolved"
        surface.append(
            {
                "purpose_id": purpose_id,
                "actor_id": purpose["actor_id"],
                "raw_expression": purpose["raw_expression"],
                "source_state": purpose["source_state"],
                "aggregate_state": aggregate,
                "branch_state_counts": {state: branch_states.count(state) for state in unique},
                "branch_count": len(branch_states),
                "details": details[:32],
            }
        )
    return surface


def _liveness_surface(
    liveness: list[dict[str, Any]],
    branches: list[Branch],
    counterexamples: dict[str, dict[str, Any]],
) -> list[dict[str, Any]]:
    results = []
    for obligation in liveness:
        branch_states: list[str] = []
        for branch in branches:
            states = [entry["state"] for entry in branch.trace]
            branch_result = "pass"
            for index, state in enumerate(states):
                if not eval_bool(obligation["trigger"], state):
                    continue
                if eval_bool(obligation["target"], state):
                    continue
                deadline = index + int(obligation["within_steps"])
                search_end = min(deadline, len(states) - 1)
                fulfilled = any(eval_bool(obligation["target"], states[j]) for j in range(index + 1, search_end + 1))
                if fulfilled:
                    continue
                if deadline <= len(states) - 1 or branch.terminated:
                    branch_result = "fail"
                    _record_counterexample(
                        counterexamples,
                        obligation["id"],
                        obligation.get("gate", "BLOCK"),
                        f"trigger at step {index} was not followed by target within {obligation['within_steps']} steps",
                        branch.trace,
                        branch.state,
                    )
                    break
                branch_result = "unresolved"
            branch_states.append(branch_result)
        unique = set(branch_states)
        if "fail" in unique:
            aggregate = "fail"
        elif "unresolved" in unique:
            aggregate = "unresolved"
        else:
            aggregate = "pass"
        results.append(
            {
                "id": obligation["id"],
                "aggregate_state": aggregate,
                "branch_state_counts": {state: branch_states.count(state) for state in sorted(unique)},
                "trigger": obligation["trigger"],
                "target": obligation["target"],
                "within_steps": obligation["within_steps"],
                "gate": obligation.get("gate", "BLOCK"),
                "source_state": obligation.get("source_state"),
            }
        )
    return results


def _outcome_surface(outcomes: list[dict[str, Any]], terminal_states: list[dict[str, Any]]) -> list[dict[str, Any]]:
    result = []
    for outcome in outcomes:
        values = [eval_expression(outcome["expression"], state) for state in terminal_states]
        numeric = all(isinstance(value, (int, float)) and not isinstance(value, bool) for value in values)
        if numeric and values:
            summary: dict[str, Any] = {
                "min": min(float(v) for v in values),
                "max": max(float(v) for v in values),
                "distinct": len(set(float(v) for v in values)),
            }
        else:
            summary = {"values": sorted({canonical_json(value) for value in values})[:32], "distinct": len({canonical_json(value) for value in values})}
        result.append(
            {
                "id": outcome["id"],
                "label": outcome.get("label", outcome["id"]),
                "expression": outcome["expression"],
                "unit": outcome.get("unit"),
                "summary": summary,
                "source_state": outcome.get("source_state"),
            }
        )
    return result


def _authorization_obligations(scenario: dict[str, Any], mission: dict[str, Any]) -> list[dict[str, Any]]:
    action_lookup = {a["id"]: a for a in scenario["actions"]}
    grants = set(mission.get("authority_grants", []))
    obligations = []
    for action_id in mission["sequence"]:
        action = action_lookup[action_id]
        required = set(action.get("required_authorities", []))
        missing = sorted(required - grants)
        obligations.append(
            {
                "id": f"authority:{action_id}",
                "kind": "authority",
                "action_id": action_id,
                "required": sorted(required),
                "granted": sorted(grants & required),
                "missing": missing,
                "state": "pass" if not missing else "fail",
                "gate": "BLOCK",
            }
        )
    return obligations


def _reversibility_obligations(scenario: dict[str, Any], mission: dict[str, Any]) -> list[dict[str, Any]]:
    action_lookup = {a["id"]: a for a in scenario["actions"]}
    recovery = set(mission.get("recovery_actions", []))
    obligations = []
    for action_id in mission["sequence"]:
        action = action_lookup[action_id]
        required = bool(action.get("requires_recovery", False))
        inverse = action.get("reversible_by")
        if not required:
            continue
        state = "pass" if inverse and inverse in recovery else "fail"
        obligations.append(
            {
                "id": f"reversibility:{action_id}",
                "kind": "reversibility",
                "action_id": action_id,
                "required_recovery_action": inverse,
                "declared_recovery_actions": sorted(recovery),
                "state": state,
                "gate": action.get("recovery_gate", "BLOCK"),
            }
        )
    return obligations


def _derive_closure_state(
    authorization: list[dict[str, Any]],
    reversibility: list[dict[str, Any]],
    invariant_surface: list[dict[str, Any]],
    liveness_surface: list[dict[str, Any]],
    purpose_surface: list[dict[str, Any]],
    truncated: bool,
) -> str:
    failures: list[tuple[str, str]] = []
    for item in authorization + reversibility:
        if item["state"] == "fail":
            failures.append((item.get("gate", "BLOCK"), item["id"]))
    for item in invariant_surface:
        if item["aggregate_state"] == "fail":
            failures.append((item.get("gate", "BLOCK"), item["id"]))
    for item in liveness_surface:
        if item["aggregate_state"] == "fail":
            failures.append((item.get("gate", "BLOCK"), item["id"]))
    if any(gate == "KILL" for gate, _ in failures):
        return "KILLED"
    if any(gate == "BLOCK" for gate, _ in failures):
        return "BLOCKED"
    if failures:
        return "CONTESTED"
    if any(item["aggregate_state"] == "veto_triggered" for item in purpose_surface):
        return "BLOCKED"
    if any(item["aggregate_state"] == "contested_across_branches" for item in purpose_surface):
        return "CONTESTED"
    if any(item["aggregate_state"] in {"unmet", "unresolved"} for item in purpose_surface):
        return "UNSETTLED"
    if any(item["aggregate_state"] == "unresolved" for item in liveness_surface) or truncated:
        return "UNSETTLED"
    return "ADMISSIBLE"


def _semantic_stability(scenario: dict[str, Any], purpose_surface: list[dict[str, Any]], closure_state: str) -> str:
    states = {p.get("source_state") for p in scenario.get("purposes", [])}
    if "absent" in states:
        return "S0"
    if "contested" in states or closure_state in {"KILLED", "BLOCKED"}:
        return "S1"
    if "context_inferred" in states or closure_state == "CONTESTED":
        return "S2"
    if closure_state == "UNSETTLED" or any(p["aggregate_state"] != "satisfied" for p in purpose_surface):
        return "S3"
    return "S4"


def _evidence_reliability(scenario: dict[str, Any]) -> str:
    evidence = scenario.get("evidence", [])
    if not evidence:
        return "Hollow"
    levels = {item.get("reliability", "Provisional") for item in evidence}
    if "Blocked" in levels:
        return "Blocked"
    if "Contested" in levels:
        return "Contested"
    if levels <= {"Solid", "Supported"}:
        return "Supported"
    if "Hollow" in levels:
        return "Hollow"
    if "Borrowed" in levels:
        return "Borrowed"
    return "Provisional"


def check_mission(
    scenario: dict[str, Any],
    mission: dict[str, Any],
    *,
    max_states: int = 20000,
    disabled_invariants: set[str] | None = None,
    disabled_purposes: set[str] | None = None,
    disabled_sequence_indexes: set[int] | None = None,
    removed_authority_grants: set[str] | None = None,
) -> dict[str, Any]:
    disabled_invariants = disabled_invariants or set()
    disabled_purposes = disabled_purposes or set()
    disabled_sequence_indexes = disabled_sequence_indexes or set()
    removed_authority_grants = removed_authority_grants or set()

    mission = deep_copy_json(mission)
    mission["purpose_ids"] = [pid for pid in mission["purpose_ids"] if pid not in disabled_purposes]
    mission["authority_grants"] = [grant for grant in mission.get("authority_grants", []) if grant not in removed_authority_grants]
    action_lookup = {a["id"]: a for a in scenario["actions"]}
    specs = variable_specs(scenario)
    invariants = [inv for inv in scenario["properties"].get("invariants", []) if inv["id"] not in disabled_invariants]
    liveness = scenario["properties"].get("liveness", [])

    init = initial_state(scenario)
    branches = [Branch(init, [{"step": 0, "action_id": None, "effect_id": None, "updates": {}, "state": deep_copy_json(init)}])]
    counterexamples: dict[str, dict[str, Any]] = {}
    invariant_observations: dict[str, list[bool]] = defaultdict(list)
    truncated = False

    authorization = _authorization_obligations(scenario, mission)
    reversibility = _reversibility_obligations(scenario, mission)
    for obligation in authorization + reversibility:
        if obligation["state"] == "fail":
            _record_counterexample(
                counterexamples,
                obligation["id"],
                obligation.get("gate", "BLOCK"),
                "required authority or recovery relation is absent",
                branches[0].trace,
                init,
            )

    for result in _evaluate_invariants(invariants, init):
        invariant_observations[result["id"]].append(result["passed"])
        if not result["passed"]:
            _record_counterexample(counterexamples, result["id"], result["gate"], "invariant failed in initial state", branches[0].trace, init)

    for step_index, action_id in enumerate(mission["sequence"], start=1):
        if step_index - 1 in disabled_sequence_indexes:
            # Counterfactual deletion preserves the timeline with an explicit no-op.
            next_branches = []
            for branch in branches:
                trace = branch.trace + [{"step": step_index, "action_id": action_id, "effect_id": "counterfactual_noop", "updates": {}, "state": deep_copy_json(branch.state)}]
                next_branches.append(Branch(dict(branch.state), trace, branch.terminated, branch.termination_reason))
            branches = next_branches
            continue
        action = action_lookup[action_id]
        next_branches: list[Branch] = []
        for branch in branches:
            if branch.terminated:
                next_branches.append(branch)
                continue
            effects = apply_action(branch.state, action, specs)
            if not effects:
                trace = branch.trace + [{"step": step_index, "action_id": action_id, "effect_id": "precondition_failed", "updates": {}, "state": deep_copy_json(branch.state)}]
                _record_counterexample(
                    counterexamples,
                    f"precondition:{action_id}",
                    "BLOCK",
                    f"precondition evaluated false: {action.get('precondition', 'True')}",
                    trace,
                    branch.state,
                )
                next_branches.append(Branch(dict(branch.state), trace, True, f"precondition:{action_id}"))
                continue
            for effect in effects:
                trace = branch.trace + [
                    {
                        "step": step_index,
                        "action_id": action_id,
                        "effect_id": effect["effect_id"],
                        "effect_weight": effect["weight"],
                        "updates": effect["updates"],
                        "state": deep_copy_json(effect["state"]),
                    }
                ]
                hard_stop = False
                for result in _evaluate_invariants(invariants, effect["state"]):
                    invariant_observations[result["id"]].append(result["passed"])
                    if not result["passed"]:
                        _record_counterexample(counterexamples, result["id"], result["gate"], "invariant failed after transition", trace, effect["state"])
                        if result["gate"] in {"BLOCK", "KILL"}:
                            hard_stop = True
                stop = _stop_reason(mission, effect["state"])
                next_branches.append(
                    Branch(
                        effect["state"],
                        trace,
                        terminated=hard_stop or stop is not None,
                        termination_reason=("hard_property_failure" if hard_stop else stop),
                    )
                )
                if len(next_branches) >= max_states:
                    truncated = True
                    break
            if truncated:
                break
        branches = next_branches[:max_states]
        if truncated:
            break

    # Extend with explicit no-op states to the declared horizon so bounded liveness has a stable clock.
    current_steps = len(mission["sequence"])
    for step in range(current_steps + 1, int(mission.get("horizon", current_steps)) + 1):
        extended = []
        for branch in branches:
            trace = branch.trace + [{"step": step, "action_id": None, "effect_id": "horizon_noop", "updates": {}, "state": deep_copy_json(branch.state)}]
            extended.append(Branch(dict(branch.state), trace, branch.terminated, branch.termination_reason))
        branches = extended

    if not branches:
        branches = [Branch(init, [{"step": 0, "action_id": None, "effect_id": None, "updates": {}, "state": init}], True, "no_branches")]

    terminal_states = [branch.state for branch in branches]
    invariant_surface = []
    for invariant in invariants:
        observations = invariant_observations.get(invariant["id"], [])
        aggregate = "pass" if observations and all(observations) else "fail"
        invariant_surface.append(
            {
                "id": invariant["id"],
                "aggregate_state": aggregate,
                "observations": len(observations),
                "failures": observations.count(False),
                "expression": invariant["expression"],
                "gate": invariant.get("gate", "BLOCK"),
                "description": invariant.get("description", invariant["id"]),
                "source_state": invariant.get("source_state"),
            }
        )
    liveness_surface = _liveness_surface(liveness, branches, counterexamples)
    purpose_surface = _purpose_surface(scenario, mission, terminal_states) if mission["purpose_ids"] else []
    outcome_surface = _outcome_surface(scenario["properties"].get("outcomes", []), terminal_states)
    closure_state = _derive_closure_state(authorization, reversibility, invariant_surface, liveness_surface, purpose_surface, truncated)

    proof_obligations = authorization + reversibility
    proof_obligations += [
        {
            "id": item["id"],
            "kind": "invariant",
            "state": item["aggregate_state"],
            "gate": item["gate"],
            "expression": item["expression"],
            "source_state": item["source_state"],
        }
        for item in invariant_surface
    ]
    proof_obligations += [
        {
            "id": item["id"],
            "kind": "liveness",
            "state": item["aggregate_state"],
            "gate": item["gate"],
            "trigger": item["trigger"],
            "target": item["target"],
            "within_steps": item["within_steps"],
            "source_state": item["source_state"],
        }
        for item in liveness_surface
    ]

    state_hashes = sorted({sha256_text(canonical_json(state)) for state in terminal_states})
    return {
        "engine": "bounded_explicit_state_model_checker",
        "closure_state": closure_state,
        "semantic_stability": _semantic_stability(scenario, purpose_surface, closure_state),
        "evidence_reliability": _evidence_reliability(scenario),
        "no_scalar_without_weights": True,
        "sequence_length": len(mission["sequence"]),
        "horizon": mission.get("horizon", len(mission["sequence"])),
        "terminal_branch_count": len(branches),
        "unique_terminal_state_count": len(state_hashes),
        "state_space_truncated": truncated,
        "max_states": max_states,
        "proof_obligations": proof_obligations,
        "invariants": invariant_surface,
        "liveness": liveness_surface,
        "plural_intent_surface": purpose_surface,
        "outcome_surface": outcome_surface,
        "counterexamples": sorted(counterexamples.values(), key=lambda item: (item["trace_length"], item["property_id"])),
        "terminal_state_digest": sha256_text(canonical_json(state_hashes)),
        "terminal_states_preview": terminal_states[:32],
        "branch_traces_preview": [branch.trace for branch in branches[:12]],
        "residuals": [
            {"id": "state_space_truncated", "state": "open" if truncated else "closed", "detail": f"max_states={max_states}"},
            {"id": "finite_model_boundary", "state": "open", "detail": "Passing a bounded synthetic model does not establish real-world safety, causality or authorization."},
        ],
    }
