from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from .constants import DIKWP_CHANNELS
from .expressions import SafeExpression
from .util import deep_copy_json, read_json

_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.:-]{1,127}$")
_SOURCE_STATES = {
    "explicit",
    "user_stipulated",
    "context_inferred",
    "contested",
    "absent",
    "source_stated",
    "readme_observed",
    "github_name_description_snapshot",
    "engineered_synthetic_scenario",
    "engineered_candidate",
    "engineered_hypothesis",
    "engineered_transition",
    "locally_observed",
    "federated_external",
}


class ValidationError(ValueError):
    pass


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise ValidationError(message)


def _require_id(value: Any, label: str) -> str:
    _require(isinstance(value, str) and bool(_ID_RE.fullmatch(value)), f"{label} must be a stable identifier")
    return value


def _require_text(value: Any, label: str, *, max_len: int = 8000) -> str:
    _require(isinstance(value, str) and bool(value.strip()), f"{label} must be non-empty text")
    _require(len(value) <= max_len, f"{label} is too long")
    return value.strip()


def _source_state(value: Any, label: str = "source_state") -> str:
    _require(isinstance(value, str) and value in _SOURCE_STATES, f"{label} is not recognized")
    return value


def validate_scenario(raw: dict[str, Any]) -> dict[str, Any]:
    scenario = deep_copy_json(raw)
    _require(isinstance(scenario, dict), "scenario must be an object")
    _require_id(scenario.get("id"), "scenario.id")
    _require_text(scenario.get("title"), "scenario.title", max_len=300)
    _require_text(scenario.get("domain"), "scenario.domain", max_len=120)
    _source_state(scenario.get("source_state"))
    _require(isinstance(scenario.get("observer_context"), dict), "observer_context must be an object")
    _require(isinstance(scenario.get("state_variables"), list) and scenario["state_variables"], "state_variables must be non-empty")

    variable_ids: set[str] = set()
    variable_types: dict[str, str] = {}
    for idx, variable in enumerate(scenario["state_variables"]):
        _require(isinstance(variable, dict), f"state_variables[{idx}] must be an object")
        vid = _require_id(variable.get("id"), f"state_variables[{idx}].id")
        _require(vid not in variable_ids, f"duplicate state variable: {vid}")
        variable_ids.add(vid)
        vtype = variable.get("type")
        _require(vtype in {"number", "integer", "boolean", "string"}, f"unsupported type for {vid}")
        variable_types[vid] = vtype
        _require("initial" in variable, f"{vid} requires an initial value")
        initial = variable["initial"]
        if vtype == "number":
            _require(isinstance(initial, (int, float)) and not isinstance(initial, bool), f"{vid} initial must be numeric")
        elif vtype == "integer":
            _require(isinstance(initial, int) and not isinstance(initial, bool), f"{vid} initial must be integer")
        elif vtype == "boolean":
            _require(isinstance(initial, bool), f"{vid} initial must be boolean")
        else:
            _require(isinstance(initial, str), f"{vid} initial must be text")
        if isinstance(initial, (int, float)) and not isinstance(initial, bool):
            if variable.get("min") is not None:
                _require(initial >= variable["min"], f"{vid} initial is below min")
            if variable.get("max") is not None:
                _require(initial <= variable["max"], f"{vid} initial is above max")
        _require_text(variable.get("source_state", "engineered_synthetic_scenario"), f"{vid}.source_state", max_len=80)

    actors = scenario.get("actors", [])
    _require(isinstance(actors, list) and actors, "actors must be non-empty")
    actor_ids: set[str] = set()
    for idx, actor in enumerate(actors):
        _require(isinstance(actor, dict), f"actors[{idx}] must be an object")
        aid = _require_id(actor.get("id"), f"actors[{idx}].id")
        _require(aid not in actor_ids, f"duplicate actor: {aid}")
        actor_ids.add(aid)
        _require_text(actor.get("label"), f"actors[{idx}].label", max_len=200)
        _require_text(actor.get("role"), f"actors[{idx}].role", max_len=100)
        _source_state(actor.get("source_state", "engineered_synthetic_scenario"), f"actors[{idx}].source_state")

    purposes = scenario.get("purposes", [])
    _require(isinstance(purposes, list) and purposes, "purposes must be non-empty")
    purpose_ids: set[str] = set()
    for idx, purpose in enumerate(purposes):
        _require(isinstance(purpose, dict), f"purposes[{idx}] must be an object")
        pid = _require_id(purpose.get("id"), f"purposes[{idx}].id")
        _require(pid not in purpose_ids, f"duplicate purpose: {pid}")
        purpose_ids.add(pid)
        _require(purpose.get("actor_id") in actor_ids, f"purpose {pid} refers to unknown actor")
        _require_text(purpose.get("raw_expression"), f"purpose {pid}.raw_expression", max_len=2000)
        _source_state(purpose.get("source_state"), f"purpose {pid}.source_state")
        for field in ("acceptance", "veto"):
            entries = purpose.get(field, [])
            _require(isinstance(entries, list), f"purpose {pid}.{field} must be an array")
            for eidx, entry in enumerate(entries):
                _require(isinstance(entry, dict), f"purpose {pid}.{field}[{eidx}] must be an object")
                _require_id(entry.get("id"), f"purpose {pid}.{field}[{eidx}].id")
                expr = _require_text(entry.get("expression"), f"purpose {pid}.{field}[{eidx}].expression")
                SafeExpression(expr, variable_ids)
                _require_text(entry.get("description", entry["id"]), f"purpose {pid}.{field}[{eidx}].description", max_len=500)

    evidence = scenario.get("evidence", [])
    _require(isinstance(evidence, list), "evidence must be an array")
    evidence_ids: set[str] = set()
    for idx, item in enumerate(evidence):
        _require(isinstance(item, dict), f"evidence[{idx}] must be an object")
        eid = _require_id(item.get("id"), f"evidence[{idx}].id")
        _require(eid not in evidence_ids, f"duplicate evidence: {eid}")
        evidence_ids.add(eid)
        _require_text(item.get("claim"), f"evidence {eid}.claim", max_len=2000)
        _source_state(item.get("source_state"), f"evidence {eid}.source_state")
        _require_text(item.get("observer", "scenario_designer"), f"evidence {eid}.observer", max_len=200)
        _require_text(item.get("scope", "synthetic_scenario"), f"evidence {eid}.scope", max_len=300)
        _require_text(item.get("reliability", "Provisional"), f"evidence {eid}.reliability", max_len=80)

    hypotheses = scenario.get("hypotheses", [])
    _require(isinstance(hypotheses, list), "hypotheses must be an array")
    hypothesis_ids: set[str] = set()
    for idx, hypothesis in enumerate(hypotheses):
        _require(isinstance(hypothesis, dict), f"hypotheses[{idx}] must be an object")
        hid = _require_id(hypothesis.get("id"), f"hypotheses[{idx}].id")
        _require(hid not in hypothesis_ids, f"duplicate hypothesis: {hid}")
        hypothesis_ids.add(hid)
        _require_text(hypothesis.get("statement"), f"hypothesis {hid}.statement", max_len=2000)
        _source_state(hypothesis.get("source_state"), f"hypothesis {hid}.source_state")
        prediction = hypothesis.get("prediction_expression")
        if prediction:
            SafeExpression(_require_text(prediction, f"hypothesis {hid}.prediction_expression"), variable_ids)
        refs = hypothesis.get("evidence_refs", [])
        _require(isinstance(refs, list) and all(ref in evidence_ids for ref in refs), f"hypothesis {hid} has unknown evidence refs")

    actions = scenario.get("actions", [])
    _require(isinstance(actions, list) and actions, "actions must be non-empty")
    action_ids: set[str] = set()
    for idx, action in enumerate(actions):
        _require(isinstance(action, dict), f"actions[{idx}] must be an object")
        action_id = _require_id(action.get("id"), f"actions[{idx}].id")
        _require(action_id not in action_ids, f"duplicate action: {action_id}")
        action_ids.add(action_id)
        _require_text(action.get("label"), f"action {action_id}.label", max_len=300)
        _source_state(action.get("source_state"), f"action {action_id}.source_state")
        required = action.get("required_authorities", [])
        _require(isinstance(required, list) and all(isinstance(x, str) and x for x in required), f"action {action_id}.required_authorities invalid")
        precondition = action.get("precondition", "True")
        SafeExpression(_require_text(precondition, f"action {action_id}.precondition"), variable_ids)
        effects = action.get("effects", [])
        _require(isinstance(effects, list) and effects, f"action {action_id} requires effects")
        effect_ids: set[str] = set()
        total_weight = 0.0
        for eidx, effect in enumerate(effects):
            _require(isinstance(effect, dict), f"action {action_id}.effects[{eidx}] must be an object")
            effect_id = _require_id(effect.get("id"), f"action {action_id}.effects[{eidx}].id")
            _require(effect_id not in effect_ids, f"duplicate effect {effect_id} in action {action_id}")
            effect_ids.add(effect_id)
            weight = effect.get("weight", 1.0)
            _require(isinstance(weight, (int, float)) and weight >= 0, f"effect {effect_id} weight invalid")
            total_weight += float(weight)
            updates = effect.get("updates", {})
            _require(isinstance(updates, dict) and updates, f"effect {effect_id} requires updates")
            for variable_id, expression in updates.items():
                _require(variable_id in variable_ids, f"effect {effect_id} updates unknown variable {variable_id}")
                if isinstance(expression, str):
                    SafeExpression(expression, variable_ids)
                else:
                    expected = variable_types[variable_id]
                    if expected in {"number", "integer"}:
                        _require(isinstance(expression, (int, float)) and not isinstance(expression, bool), f"literal update for {variable_id} must be numeric")
                    elif expected == "boolean":
                        _require(isinstance(expression, bool), f"literal update for {variable_id} must be boolean")
                    else:
                        _require(isinstance(expression, str), f"literal update for {variable_id} must be text")
        _require(total_weight > 0, f"action {action_id} effect weights sum to zero")
        if action.get("reversible_by") is not None:
            _require_id(action["reversible_by"], f"action {action_id}.reversible_by")

    for action in actions:
        if action.get("reversible_by"):
            _require(action["reversible_by"] in action_ids, f"action {action['id']} reversible_by is unknown")

    properties = scenario.get("properties", {})
    _require(isinstance(properties, dict), "properties must be an object")
    property_ids: set[str] = set()
    for field in ("invariants", "liveness", "outcomes"):
        _require(isinstance(properties.get(field, []), list), f"properties.{field} must be an array")
    for idx, inv in enumerate(properties.get("invariants", [])):
        iid = _require_id(inv.get("id"), f"invariants[{idx}].id")
        _require(iid not in property_ids, f"duplicate property id: {iid}")
        property_ids.add(iid)
        SafeExpression(_require_text(inv.get("expression"), f"invariant {iid}.expression"), variable_ids)
        _require(inv.get("gate", "BLOCK") in {"REVIEW", "HOLD", "BLOCK", "KILL"}, f"invariant {iid}.gate invalid")
        _source_state(inv.get("source_state", "engineered_synthetic_scenario"), f"invariant {iid}.source_state")
    for idx, live in enumerate(properties.get("liveness", [])):
        lid = _require_id(live.get("id"), f"liveness[{idx}].id")
        _require(lid not in property_ids, f"duplicate property id: {lid}")
        property_ids.add(lid)
        SafeExpression(_require_text(live.get("trigger"), f"liveness {lid}.trigger"), variable_ids)
        SafeExpression(_require_text(live.get("target"), f"liveness {lid}.target"), variable_ids)
        _require(isinstance(live.get("within_steps"), int) and live["within_steps"] >= 0, f"liveness {lid}.within_steps invalid")
        _require(live.get("gate", "BLOCK") in {"REVIEW", "HOLD", "BLOCK", "KILL"}, f"liveness {lid}.gate invalid")
        _source_state(live.get("source_state", "engineered_synthetic_scenario"), f"liveness {lid}.source_state")
    for idx, outcome in enumerate(properties.get("outcomes", [])):
        oid = _require_id(outcome.get("id"), f"outcomes[{idx}].id")
        _require(oid not in property_ids, f"duplicate property id: {oid}")
        property_ids.add(oid)
        SafeExpression(_require_text(outcome.get("expression"), f"outcome {oid}.expression"), variable_ids)
        _source_state(outcome.get("source_state", "engineered_synthetic_scenario"), f"outcome {oid}.source_state")

    missions = scenario.get("missions", [])
    _require(isinstance(missions, list) and missions, "missions must be non-empty")
    mission_ids: set[str] = set()
    for idx, mission in enumerate(missions):
        _require(isinstance(mission, dict), f"missions[{idx}] must be an object")
        mid = _require_id(mission.get("id"), f"missions[{idx}].id")
        _require(mid not in mission_ids, f"duplicate mission: {mid}")
        mission_ids.add(mid)
        _require_text(mission.get("title"), f"mission {mid}.title", max_len=300)
        _source_state(mission.get("source_state", "engineered_candidate"), f"mission {mid}.source_state")
        refs = mission.get("purpose_ids", [])
        _require(isinstance(refs, list) and refs and all(ref in purpose_ids for ref in refs), f"mission {mid} has invalid purpose_ids")
        sequence = mission.get("sequence", [])
        _require(isinstance(sequence, list) and sequence and all(ref in action_ids for ref in sequence), f"mission {mid} has invalid sequence")
        horizon = mission.get("horizon", len(sequence))
        _require(isinstance(horizon, int) and horizon >= len(sequence) and horizon <= 64, f"mission {mid}.horizon invalid")
        grants = mission.get("authority_grants", [])
        _require(isinstance(grants, list) and all(isinstance(x, str) and x for x in grants), f"mission {mid}.authority_grants invalid")
        stops = mission.get("stop_conditions", [])
        _require(isinstance(stops, list), f"mission {mid}.stop_conditions must be an array")
        for sidx, stop in enumerate(stops):
            _require(isinstance(stop, dict), f"mission {mid}.stop_conditions[{sidx}] invalid")
            _require_id(stop.get("id"), f"mission {mid}.stop_conditions[{sidx}].id")
            SafeExpression(_require_text(stop.get("expression"), f"mission {mid}.stop_conditions[{sidx}].expression"), variable_ids)
        recovery = mission.get("recovery_actions", [])
        _require(isinstance(recovery, list) and all(ref in action_ids for ref in recovery), f"mission {mid}.recovery_actions invalid")
        module_pipeline = mission.get("module_pipeline", [])
        _require(isinstance(module_pipeline, list) and all(isinstance(x, str) and x for x in module_pipeline), f"mission {mid}.module_pipeline invalid")

    mesh_relations = scenario.get("mesh_relations", [])
    _require(isinstance(mesh_relations, list), "mesh_relations must be an array")
    for idx, rel in enumerate(mesh_relations):
        _require(isinstance(rel, dict), f"mesh_relations[{idx}] must be an object")
        _require_id(rel.get("id"), f"mesh_relations[{idx}].id")
        _require(rel.get("channel") in DIKWP_CHANNELS, f"mesh_relations[{idx}].channel invalid")
        _require_text(rel.get("source"), f"mesh_relations[{idx}].source", max_len=200)
        _require_text(rel.get("target"), f"mesh_relations[{idx}].target", max_len=200)
        _require_text(rel.get("relation"), f"mesh_relations[{idx}].relation", max_len=500)
        _source_state(rel.get("source_state", "engineered_synthetic_scenario"), f"mesh_relations[{idx}].source_state")

    scenario.setdefault("sensitivity", "public_synthetic")
    scenario.setdefault("non_claims", [])
    scenario.setdefault("settlement_contract", [])
    return scenario


def load_scenario(path: str | Path) -> dict[str, Any]:
    raw = read_json(path)
    if not isinstance(raw, dict):
        raise ValidationError("scenario file root must be an object")
    return validate_scenario(raw)


def validate_module_manifest(raw: dict[str, Any]) -> dict[str, Any]:
    manifest = deep_copy_json(raw)
    _require_id(manifest.get("id"), "module.id")
    _require_text(manifest.get("name"), "module.name", max_len=300)
    _require_text(manifest.get("source_url"), "module.source_url", max_len=1000)
    _source_state(manifest.get("source_state"), "module.source_state")
    _require(isinstance(manifest.get("observed_capabilities"), list), "module.observed_capabilities must be an array")
    _require(isinstance(manifest.get("integration_slots"), list) and manifest["integration_slots"], "module.integration_slots must be non-empty")
    _require(isinstance(manifest.get("limitations"), list), "module.limitations must be an array")
    _require(isinstance(manifest.get("input_artifacts", []), list), "module.input_artifacts invalid")
    _require(isinstance(manifest.get("output_artifacts", []), list), "module.output_artifacts invalid")
    return manifest
