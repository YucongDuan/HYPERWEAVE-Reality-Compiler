from __future__ import annotations

import random
from collections import Counter, defaultdict
from typing import Any

from .expressions import eval_bool, eval_expression
from .modelcheck import apply_action, initial_state, variable_specs
from .util import percentile, sha256_text, canonical_json


def _weighted_choice(rng: random.Random, effects: list[dict[str, Any]]) -> dict[str, Any]:
    point = rng.random()
    cumulative = 0.0
    for effect in effects:
        cumulative += effect["weight"]
        if point <= cumulative:
            return effect
    return effects[-1]


def simulate_mission(
    scenario: dict[str, Any],
    mission: dict[str, Any],
    *,
    trials: int = 1000,
    seed: int = 20260722,
) -> dict[str, Any]:
    if trials < 1 or trials > 100000:
        raise ValueError("trials must be between 1 and 100000")
    rng = random.Random(seed)
    specs = variable_specs(scenario)
    action_lookup = {action["id"]: action for action in scenario["actions"]}
    invariant_lookup = scenario["properties"].get("invariants", [])
    purpose_lookup = {purpose["id"]: purpose for purpose in scenario["purposes"]}
    finals: list[dict[str, Any]] = []
    effect_counts: Counter[str] = Counter()
    violation_counts: Counter[str] = Counter()
    stop_counts: Counter[str] = Counter()
    purpose_counts: dict[str, Counter[str]] = {pid: Counter() for pid in mission["purpose_ids"]}

    for _ in range(trials):
        state = initial_state(scenario)
        stopped = False
        for action_id in mission["sequence"]:
            action = action_lookup[action_id]
            effects = apply_action(state, action, specs)
            if not effects:
                violation_counts[f"precondition:{action_id}"] += 1
                stopped = True
                break
            effect = _weighted_choice(rng, effects)
            state = effect["state"]
            effect_counts[f"{action_id}:{effect['effect_id']}"] += 1
            hard = False
            for invariant in invariant_lookup:
                if not eval_bool(invariant["expression"], state):
                    violation_counts[invariant["id"]] += 1
                    if invariant.get("gate", "BLOCK") in {"BLOCK", "KILL"}:
                        hard = True
            for stop in mission.get("stop_conditions", []):
                if eval_bool(stop["expression"], state):
                    stop_counts[stop["id"]] += 1
                    stopped = True
                    break
            if hard or stopped:
                break
        finals.append(state)
        for purpose_id in mission["purpose_ids"]:
            purpose = purpose_lookup[purpose_id]
            veto = any(eval_bool(item["expression"], state) for item in purpose.get("veto", []))
            accepted = bool(purpose.get("acceptance")) and all(eval_bool(item["expression"], state) for item in purpose.get("acceptance", []))
            if veto:
                purpose_counts[purpose_id]["veto_triggered"] += 1
            elif accepted:
                purpose_counts[purpose_id]["satisfied"] += 1
            else:
                purpose_counts[purpose_id]["unmet_or_unresolved"] += 1

    variable_summaries: dict[str, Any] = {}
    for variable in scenario["state_variables"]:
        vid = variable["id"]
        values = [state[vid] for state in finals]
        if variable["type"] in {"number", "integer"}:
            numbers = [float(value) for value in values]
            variable_summaries[vid] = {
                "unit": variable.get("unit"),
                "min": min(numbers),
                "p10": percentile(numbers, 0.10),
                "median": percentile(numbers, 0.50),
                "p90": percentile(numbers, 0.90),
                "max": max(numbers),
                "mean": sum(numbers) / len(numbers),
            }
        else:
            counts = Counter(canonical_json(value) for value in values)
            variable_summaries[vid] = {"counts": dict(sorted(counts.items()))}

    outcome_summaries = []
    for outcome in scenario["properties"].get("outcomes", []):
        values = [eval_expression(outcome["expression"], state) for state in finals]
        if all(isinstance(value, (int, float)) and not isinstance(value, bool) for value in values):
            numbers = [float(value) for value in values]
            summary = {
                "min": min(numbers),
                "p10": percentile(numbers, 0.10),
                "median": percentile(numbers, 0.50),
                "p90": percentile(numbers, 0.90),
                "max": max(numbers),
            }
        else:
            summary = {"counts": dict(Counter(canonical_json(value) for value in values))}
        outcome_summaries.append(
            {
                "id": outcome["id"],
                "label": outcome.get("label", outcome["id"]),
                "unit": outcome.get("unit"),
                "summary": summary,
            }
        )

    return {
        "engine": "seeded_branch_sampler",
        "seed": seed,
        "trials": trials,
        "synthetic_only": True,
        "effect_counts": dict(sorted(effect_counts.items())),
        "property_violation_counts": dict(sorted(violation_counts.items())),
        "stop_counts": dict(sorted(stop_counts.items())),
        "purpose_branch_counts": {key: dict(value) for key, value in purpose_counts.items()},
        "variable_summaries": variable_summaries,
        "outcome_summaries": outcome_summaries,
        "final_state_digest": sha256_text(canonical_json(finals)),
        "boundary": "Sampling summarizes the declared synthetic transition branches; it is not a calibrated forecast or a substitute for formal worst-case exploration.",
    }
