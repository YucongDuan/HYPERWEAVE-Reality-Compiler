from __future__ import annotations

import platform
import sys
from typing import Any

from .constants import PROJECT_BOUNDARY, SYSTEM_ID, VERSION
from .kernel import derive_intent_conditioned_kernel
from .mesh import build_mesh
from .modelcheck import check_mission
from .simulation import simulate_mission
from .util import canonical_json, make_id, sha256_text, utc_now


def compile_reality_experiment(
    scenario_record: dict[str, Any],
    mission_id: str,
    module_manifests: list[dict[str, Any]],
    *,
    actor: str,
    trials: int = 1000,
    seed: int = 20260722,
    max_states: int = 20000,
) -> dict[str, Any]:
    scenario = scenario_record["payload"]
    mission = next((item for item in scenario["missions"] if item["id"] == mission_id), None)
    if mission is None:
        raise KeyError(f"mission not found: {mission_id}")
    manifest_lookup = {item["id"]: item for item in module_manifests}
    missing_modules = [module_id for module_id in mission.get("module_pipeline", []) if module_id not in manifest_lookup]
    if missing_modules:
        raise ValueError(f"mission references missing module manifests: {missing_modules}")

    formal = check_mission(scenario, mission, max_states=max_states)
    simulation = simulate_mission(scenario, mission, trials=trials, seed=seed)
    kernel = derive_intent_conditioned_kernel(scenario, mission, formal, max_states=max_states)
    mesh = build_mesh(scenario, mission, formal, simulation, kernel)

    compilation_id = make_id("comp")
    created_at = utc_now()
    selected_modules = [manifest_lookup[module_id] for module_id in mission.get("module_pipeline", [])]
    purpose_lookup = {item["id"]: item for item in scenario["purposes"]}
    purpose_contracts = [purpose_lookup[pid] for pid in mission["purpose_ids"]]
    source_manifest = {
        "scenario": {
            "id": scenario["id"],
            "revision": scenario_record["revision"],
            "payload_hash": scenario_record["payload_hash"],
            "source_state": scenario["source_state"],
            "sensitivity": scenario.get("sensitivity", "public_synthetic"),
        },
        "evidence": [
            {
                "id": item["id"],
                "claim_hash": sha256_text(item["claim"]),
                "source_state": item["source_state"],
                "observer": item.get("observer"),
                "scope": item.get("scope"),
                "reliability": item.get("reliability"),
            }
            for item in scenario.get("evidence", [])
        ],
        "modules": [
            {
                "id": item["id"],
                "name": item["name"],
                "source_url": item["source_url"],
                "source_state": item["source_state"],
                "observed_at": item.get("observed_at"),
                "manifest_hash": sha256_text(canonical_json(item)),
                "authority_inherited": False,
            }
            for item in selected_modules
        ],
    }
    capsule = {
        "capsule_version": "1.0",
        "system_id": SYSTEM_ID,
        "system_version": VERSION,
        "compilation_id": compilation_id,
        "created_at": created_at,
        "created_by": actor,
        "engineering_handle_boundary": PROJECT_BOUNDARY,
        "scenario": {
            "id": scenario["id"],
            "title": scenario["title"],
            "domain": scenario["domain"],
            "observer_context": scenario["observer_context"],
            "source_state": scenario["source_state"],
            "sensitivity": scenario.get("sensitivity", "public_synthetic"),
            "revision": scenario_record["revision"],
        },
        "mission": mission,
        "purpose_contracts": purpose_contracts,
        "authority_envelope": {
            "grants": mission.get("authority_grants", []),
            "authorized_by": mission.get("authorized_by", []),
            "forbidden_outcomes": mission.get("forbidden_outcomes", []),
            "stop_conditions": mission.get("stop_conditions", []),
            "recovery_actions": mission.get("recovery_actions", []),
            "no_reality_authority_created": True,
        },
        "source_manifest": source_manifest,
        "module_pipeline": selected_modules,
        "formal": formal,
        "simulation": simulation,
        "intent_conditioned_kernel": kernel,
        "mesh": mesh,
        "settlement_contract": scenario.get("settlement_contract", []),
        "status_dimensions": {
            "closure_state": formal["closure_state"],
            "semantic_stability": formal["semantic_stability"],
            "mesh_examination": mesh["mesh_examination"],
            "evidence_reliability": formal["evidence_reliability"],
            "no_scalar_without_explicit_weights": True,
        },
        "runtime_manifest": {
            "python": sys.version.split()[0],
            "implementation": platform.python_implementation(),
            "platform": platform.platform(),
            "seed": seed,
            "trials": trials,
            "max_states": max_states,
            "network_used": False,
            "external_model_used": False,
        },
        "proof_carrying_certificate": {
            "scenario_hash": scenario_record["payload_hash"],
            "formal_result_hash": sha256_text(canonical_json(formal)),
            "simulation_result_hash": sha256_text(canonical_json(simulation)),
            "kernel_hash": kernel["kernel_hash"],
            "mesh_hash": mesh["mesh_hash"],
            "counterexample_count": len(formal["counterexamples"]),
            "certificate_scope": "bounded explicit-state model, declared expressions, synthetic transition branches and local source manifest",
            "external_validity_claimed": False,
        },
        "residuals": [
            {
                "id": "portfolio_completeness",
                "state": "open",
                "detail": "The GitHub analysis is a public-page and selected-README observation, not a full authenticated code audit of every repository.",
            },
            {
                "id": "real_world_model_gap",
                "state": "open",
                "detail": "The finite causal model may omit actors, variables, feedback loops, legal constraints and rare events.",
            },
            {
                "id": "authority_gap",
                "state": "open",
                "detail": "A proof-carrying capsule does not create institutional, democratic, clinical, legal or scientific authority.",
            },
        ],
        "non_claims": scenario.get("non_claims", [])
        + [
            "No claim is made about the private cognition, imagination or endorsement of Yucong Duan or any institution.",
            "No formal proof over the bounded model is represented as proof of real-world safety or causal truth.",
            "No mission status is an action recommendation or autonomous authorization.",
        ],
    }
    capsule_hash = sha256_text(canonical_json(capsule))
    return {
        "id": compilation_id,
        "scenario_id": scenario["id"],
        "scenario_revision": scenario_record["revision"],
        "mission_id": mission_id,
        "status": formal["closure_state"],
        "semantic_stability": formal["semantic_stability"],
        "mesh_examination": mesh["mesh_examination"],
        "evidence_reliability": formal["evidence_reliability"],
        "seed": seed,
        "trials": trials,
        "capsule": capsule,
        "capsule_hash": capsule_hash,
        "created_by": actor,
        "created_at": created_at,
    }
