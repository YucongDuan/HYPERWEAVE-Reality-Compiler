from __future__ import annotations

import hashlib
import hmac
from typing import Any

from .util import canonical_json, deep_copy_json, make_id, sha256_text, utc_now


def export_evidence_bundle(
    compilation: dict[str, Any],
    *,
    node_id: str,
    shared_secret: str | None = None,
) -> dict[str, Any]:
    capsule = deep_copy_json(compilation["capsule"])
    sensitivity = capsule.get("scenario", {}).get("sensitivity", "public_synthetic")
    # Raw expressions are preserved for public synthetic scenarios. Restricted scenarios retain hashes only.
    if sensitivity in {"restricted", "secret"}:
        for purpose in capsule.get("purpose_contracts", []):
            purpose["raw_expression_hash"] = sha256_text(purpose.get("raw_expression", ""))
            purpose["raw_expression"] = "[REDACTED]"
        capsule.get("scenario", {}).pop("observer_context", None)
        capsule.get("formal", {}).pop("terminal_states_preview", None)
        capsule.get("formal", {}).pop("branch_traces_preview", None)
    bundle = {
        "id": make_id("bundle"),
        "bundle_version": "1.0",
        "created_at": utc_now(),
        "source_node_id": node_id,
        "authority_inherited": False,
        "sensitivity": sensitivity,
        "compilation_id": compilation["id"],
        "capsule": capsule,
        "compilation_hash": compilation["capsule_hash"],
        "boundary": "Integrity verification does not transfer local authorization, institutional endorsement, legal validity or scientific truth.",
    }
    payload_hash = sha256_text(canonical_json(bundle))
    attestation = {
        "mode": "HMAC-SHA256-demo" if shared_secret else "SHA256-only",
        "payload_hash": payload_hash,
        "value": hmac.new(shared_secret.encode(), payload_hash.encode(), hashlib.sha256).hexdigest() if shared_secret else None,
    }
    return {"bundle": bundle, "attestation": attestation}


def verify_evidence_bundle(package: dict[str, Any], shared_secret: str | None = None) -> dict[str, Any]:
    bundle = package.get("bundle")
    attestation = package.get("attestation", {})
    if not isinstance(bundle, dict):
        return {"valid": False, "reason": "bundle is absent", "authority_inherited": False}
    payload_hash = sha256_text(canonical_json(bundle))
    hash_valid = hmac.compare_digest(payload_hash, str(attestation.get("payload_hash", "")))
    signature_valid: bool | None
    if attestation.get("mode") == "HMAC-SHA256-demo":
        if not shared_secret:
            signature_valid = False
        else:
            expected = hmac.new(shared_secret.encode(), payload_hash.encode(), hashlib.sha256).hexdigest()
            signature_valid = hmac.compare_digest(expected, str(attestation.get("value", "")))
    else:
        signature_valid = None
    valid = hash_valid and signature_valid is not False
    return {
        "valid": valid,
        "hash_valid": hash_valid,
        "signature_valid": signature_valid,
        "authority_inherited": False,
        "source_node_id": bundle.get("source_node_id"),
        "compilation_id": bundle.get("compilation_id"),
        "boundary": "A valid integrity record is not an authority grant or a field-validation result.",
    }
