from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .db import Database
from .util import canonical_json, read_json, sha256_text, utc_now
from .validation import load_scenario, validate_module_manifest


def seed_project(db: Database, root: str | Path) -> dict[str, int]:
    project_root = Path(root)
    counts = {"portfolio_projects": 0, "module_manifests": 0, "scenarios": 0, "nodes": 0}
    now = utc_now()
    portfolio_path = project_root / "data" / "portfolio_snapshot.json"
    module_dir = project_root / "data" / "module_manifests"
    scenario_dir = project_root / "data" / "scenarios"

    with db.transaction() as conn:
        if portfolio_path.exists():
            snapshot = read_json(portfolio_path)
            for project in snapshot.get("projects", []):
                cursor = conn.execute(
                    """INSERT OR IGNORE INTO portfolio_projects(
                        id,repo_name,cluster,claimed_capability,source_state,source_url,integration_slots_json,evidence_state,observed_at,notes
                    ) VALUES (?,?,?,?,?,?,?,?,?,?)""",
                    (
                        project["id"],
                        project["repo_name"],
                        project["cluster"],
                        project["claimed_capability"],
                        project["source_state"],
                        project["source_url"],
                        canonical_json(project.get("integration_slots", [])),
                        project["evidence_state"],
                        project["observed_at"],
                        project.get("notes", ""),
                    ),
                )
                counts["portfolio_projects"] += max(cursor.rowcount, 0)

        for path in sorted(module_dir.glob("*.json")):
            manifest = validate_module_manifest(read_json(path))
            payload_json = canonical_json(manifest)
            cursor = conn.execute(
                """INSERT OR IGNORE INTO module_manifests(id,name,source_url,source_state,observed_at,payload_json,payload_hash)
                   VALUES (?,?,?,?,?,?,?)""",
                (
                    manifest["id"],
                    manifest["name"],
                    manifest["source_url"],
                    manifest["source_state"],
                    manifest.get("observed_at", "2026-07-22"),
                    payload_json,
                    sha256_text(payload_json),
                ),
            )
            counts["module_manifests"] += max(cursor.rowcount, 0)

        for path in sorted(scenario_dir.glob("*.json")):
            scenario = load_scenario(path)
            payload_json = canonical_json(scenario)
            cursor = conn.execute(
                """INSERT OR IGNORE INTO scenarios(id,title,domain,source_state,sensitivity,revision,payload_json,payload_hash,created_at,updated_at)
                   VALUES (?,?,?,?,?,?,?,?,?,?)""",
                (
                    scenario["id"],
                    scenario["title"],
                    scenario["domain"],
                    scenario["source_state"],
                    scenario.get("sensitivity", "public_synthetic"),
                    1,
                    payload_json,
                    sha256_text(payload_json),
                    now,
                    now,
                ),
            )
            counts["scenarios"] += max(cursor.rowcount, 0)

        if not conn.execute("SELECT id FROM nodes WHERE id='node_cn_shanghai_demo'").fetchone():
            conn.execute(
                """INSERT INTO nodes(id,name,jurisdiction,operator,data_residency,shared_secret,source_state,created_at,updated_at)
                   VALUES (?,?,?,?,?,?,?,?,?)""",
                (
                    "node_cn_shanghai_demo",
                    "上海本地合成验证节点",
                    "CN-Shanghai",
                    "local_demo_operator",
                    "local_sqlite_only",
                    "hyperweave-demo-shared-secret",
                    "engineered_synthetic_scenario",
                    now,
                    now,
                ),
            )
            counts["nodes"] += 1
        conn.execute("INSERT OR REPLACE INTO meta(key,value) VALUES ('local_node_id','node_cn_shanghai_demo')")
        if any(counts.values()):
            db.append_audit(conn, "system", "seed_project", "system", "hyperweave", counts)
    return counts
