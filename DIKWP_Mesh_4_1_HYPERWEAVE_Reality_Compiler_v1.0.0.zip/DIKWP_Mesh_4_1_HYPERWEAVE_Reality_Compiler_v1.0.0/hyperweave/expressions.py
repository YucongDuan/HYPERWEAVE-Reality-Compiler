from __future__ import annotations

import ast
import math
from typing import Any, Mapping


class ExpressionError(ValueError):
    pass


_ALLOWED_FUNCS = {
    "min": min,
    "max": max,
    "abs": abs,
    "round": round,
    "floor": math.floor,
    "ceil": math.ceil,
}

_ALLOWED_NODES = (
    ast.Expression,
    ast.BoolOp,
    ast.BinOp,
    ast.UnaryOp,
    ast.Compare,
    ast.Name,
    ast.Load,
    ast.Constant,
    ast.Call,
    ast.IfExp,
    ast.And,
    ast.Or,
    ast.Not,
    ast.Add,
    ast.Sub,
    ast.Mult,
    ast.Div,
    ast.FloorDiv,
    ast.Mod,
    ast.Pow,
    ast.USub,
    ast.UAdd,
    ast.Eq,
    ast.NotEq,
    ast.Lt,
    ast.LtE,
    ast.Gt,
    ast.GtE,
    ast.In,
    ast.NotIn,
    ast.List,
    ast.Tuple,
)


class SafeExpression:
    """A deliberately small expression evaluator for finite synthetic state models."""

    def __init__(self, expression: str, allowed_names: set[str] | None = None):
        if not isinstance(expression, str) or not expression.strip():
            raise ExpressionError("expression must be a non-empty string")
        if len(expression) > 1000:
            raise ExpressionError("expression is too long")
        self.expression = expression.strip()
        try:
            self.tree = ast.parse(self.expression, mode="eval")
        except SyntaxError as exc:
            raise ExpressionError(f"invalid expression syntax: {exc.msg}") from exc
        self.allowed_names = allowed_names
        self._validate()
        self.code = compile(self.tree, "<hyperweave-expression>", "eval")

    def _validate(self) -> None:
        for node in ast.walk(self.tree):
            if not isinstance(node, _ALLOWED_NODES):
                raise ExpressionError(f"forbidden expression node: {type(node).__name__}")
            if isinstance(node, ast.Call):
                if not isinstance(node.func, ast.Name) or node.func.id not in _ALLOWED_FUNCS:
                    raise ExpressionError("only min/max/abs/round/floor/ceil calls are allowed")
                if node.keywords:
                    raise ExpressionError("keyword arguments are not allowed")
            if isinstance(node, ast.Name):
                if node.id in _ALLOWED_FUNCS:
                    continue
                if self.allowed_names is not None and node.id not in self.allowed_names:
                    raise ExpressionError(f"unknown state name: {node.id}")
            if isinstance(node, ast.Pow):
                # Power is allowed, but callers still provide bounded state variables.
                continue

    def evaluate(self, state: Mapping[str, Any]) -> Any:
        env = dict(_ALLOWED_FUNCS)
        env.update(state)
        try:
            return eval(self.code, {"__builtins__": {}}, env)  # noqa: S307 - AST is strictly validated.
        except Exception as exc:
            raise ExpressionError(f"evaluation failed for {self.expression!r}: {exc}") from exc


def eval_expression(expression: str, state: Mapping[str, Any]) -> Any:
    return SafeExpression(expression, set(state.keys())).evaluate(state)


def eval_bool(expression: str, state: Mapping[str, Any]) -> bool:
    return bool(eval_expression(expression, state))
