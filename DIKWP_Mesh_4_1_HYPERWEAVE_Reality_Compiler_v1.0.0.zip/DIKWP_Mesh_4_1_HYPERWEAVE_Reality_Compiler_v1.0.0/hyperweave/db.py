from __future__ import annotations

import json
import sqlite3
import threading
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator

from .auth import expired, expiry, hash_password, issue_token, verify_password
from .constants import DEFAULT_DEMO_PASSWORD, DEMO_USERS, SYSTEM_ID, VERSION
from .util import canonical_json, make_id, sha256_text, utc_now


class ClosingConnection(sqlite3.Connection):
    def __exit__(self, exc_type, exc_value, traceback):  # type: ignore[no-untyped-def]
        try:
            return super().__exit__(exc_type, exc_value, traceback)
        finally:
            self.close()


SCHEMA = """
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS users (
    username TEXT PRIMARY KEY,
    display_name TEXT NOT NULL,
    role TEXT NOT NULL,
    salt TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
    token TEXT PRIMARY KEY,
    username TEXT NOT NULL REFERENCES users(username) ON DELETE CASCADE,
    expires_at TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS module_manifests (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    source_url TEXT NOT NULL,
    source_state TEXT NOT NULL,
    observed_at TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    payload_hash TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS portfolio_projects (
    id TEXT PRIMARY KEY,
    repo_name TEXT NOT NULL UNIQUE,
    cluster TEXT NOT NULL,
    claimed_capability TEXT NOT NULL,
    source_state TEXT NOT NULL,
    source_url TEXT NOT NULL,
    integration_slots_json TEXT NOT NULL,
    evidence_state TEXT NOT NULL,
    observed_at TEXT NOT NULL,
    notes TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS scenarios (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    domain TEXT NOT NULL,
    source_state TEXT NOT NULL,
    sensitivity TEXT NOT NULL,
    revision INTEGER NOT NULL,
    payload_json TEXT NOT NULL,
    payload_hash TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS compilations (
    id TEXT PRIMARY KEY,
    scenario_id TEXT NOT NULL REFERENCES scenarios(id),
    scenario_revision INTEGER NOT NULL,
    mission_id TEXT NOT NULL,
    status TEXT NOT NULL,
    semantic_stability TEXT NOT NULL,
    mesh_examination TEXT NOT NULL,
    evidence_reliability TEXT NOT NULL,
    seed INTEGER NOT NULL,
    trials INTEGER NOT NULL,
    capsule_json TEXT NOT NULL,
    capsule_hash TEXT NOT NULL,
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS settlements (
    id TEXT PRIMARY KEY,
    compilation_id TEXT NOT NULL REFERENCES compilations(id),
    status TEXT NOT NULL,
    observation_json TEXT NOT NULL,
    result_json TEXT NOT NULL,
    result_hash TEXT NOT NULL,
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS nodes (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    jurisdiction TEXT NOT NULL,
    operator TEXT NOT NULL,
    data_residency TEXT NOT NULL,
    shared_secret TEXT,
    source_state TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS evidence_imports (
    id TEXT PRIMARY KEY,
    bundle_id TEXT NOT NULL,
    source_node_id TEXT,
    status TEXT NOT NULL,
    authority_inherited INTEGER NOT NULL DEFAULT 0,
    verification_json TEXT NOT NULL,
    package_json TEXT NOT NULL,
    imported_by TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_events (
    seq INTEGER PRIMARY KEY AUTOINCREMENT,
    event_id TEXT NOT NULL UNIQUE,
    actor TEXT NOT NULL,
    action TEXT NOT NULL,
    object_type TEXT NOT NULL,
    object_id TEXT NOT NULL,
    payload_hash TEXT NOT NULL,
    prev_hash TEXT NOT NULL,
    event_hash TEXT NOT NULL UNIQUE,
    created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_scenarios_domain ON scenarios(domain, title);
CREATE INDEX IF NOT EXISTS idx_compilations_scenario ON compilations(scenario_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_settlements_compilation ON settlements(compilation_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_object ON audit_events(object_type, object_id, seq);
CREATE INDEX IF NOT EXISTS idx_portfolio_cluster ON portfolio_projects(cluster, repo_name);
"""


class Database:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()

    def connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.path), timeout=30, isolation_level=None, factory=ClosingConnection)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA busy_timeout=30000")
        return conn

    def initialize(self) -> None:
        with self._lock, self.connect() as conn:
            conn.executescript(SCHEMA)
            now = utc_now()
            for key, value in {
                "system_id": SYSTEM_ID,
                "version": VERSION,
                "schema_version": "1",
                "created_at": now,
            }.items():
                conn.execute("INSERT OR IGNORE INTO meta(key,value) VALUES (?,?)", (key, value))
            self._seed_users(conn)

    def _seed_users(self, conn: sqlite3.Connection) -> None:
        if conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]:
            return
        now = utc_now()
        for username, display_name, role in DEMO_USERS:
            salt, digest = hash_password(DEFAULT_DEMO_PASSWORD)
            conn.execute(
                "INSERT INTO users(username,display_name,role,salt,password_hash,active,created_at) VALUES (?,?,?,?,?,?,?)",
                (username, display_name, role, salt, digest, 1, now),
            )
        self.append_audit(conn, "system", "seed_demo_users", "system", SYSTEM_ID, {"user_count": len(DEMO_USERS)})

    @contextmanager
    def transaction(self) -> Iterator[sqlite3.Connection]:
        with self._lock:
            conn = self.connect()
            try:
                conn.execute("BEGIN IMMEDIATE")
                yield conn
                conn.execute("COMMIT")
            except Exception:
                conn.execute("ROLLBACK")
                raise
            finally:
                conn.close()

    def query_all(self, sql: str, params: tuple[Any, ...] = ()) -> list[dict[str, Any]]:
        with self.connect() as conn:
            return [dict(row) for row in conn.execute(sql, params).fetchall()]

    def query_one(self, sql: str, params: tuple[Any, ...] = ()) -> dict[str, Any] | None:
        with self.connect() as conn:
            row = conn.execute(sql, params).fetchone()
            return dict(row) if row else None

    def append_audit(
        self,
        conn: sqlite3.Connection,
        actor: str,
        action: str,
        object_type: str,
        object_id: str,
        payload: Any,
    ) -> dict[str, Any]:
        previous = conn.execute("SELECT event_hash FROM audit_events ORDER BY seq DESC LIMIT 1").fetchone()
        prev_hash = previous[0] if previous else "0" * 64
        created_at = utc_now()
        event_id = make_id("evt")
        payload_hash = sha256_text(canonical_json(payload))
        event_material = {
            "event_id": event_id,
            "actor": actor,
            "action": action,
            "object_type": object_type,
            "object_id": object_id,
            "payload_hash": payload_hash,
            "prev_hash": prev_hash,
            "created_at": created_at,
        }
        event_hash = sha256_text(canonical_json(event_material))
        conn.execute(
            "INSERT INTO audit_events(event_id,actor,action,object_type,object_id,payload_hash,prev_hash,event_hash,created_at) VALUES (?,?,?,?,?,?,?,?,?)",
            (event_id, actor, action, object_type, object_id, payload_hash, prev_hash, event_hash, created_at),
        )
        return {**event_material, "event_hash": event_hash}

    def verify_audit(self) -> dict[str, Any]:
        rows = self.query_all("SELECT * FROM audit_events ORDER BY seq")
        previous = "0" * 64
        for row in rows:
            material = {
                "event_id": row["event_id"],
                "actor": row["actor"],
                "action": row["action"],
                "object_type": row["object_type"],
                "object_id": row["object_id"],
                "payload_hash": row["payload_hash"],
                "prev_hash": row["prev_hash"],
                "created_at": row["created_at"],
            }
            calculated = sha256_text(canonical_json(material))
            if row["prev_hash"] != previous or calculated != row["event_hash"]:
                return {"valid": False, "events": len(rows), "failed_seq": row["seq"]}
            previous = row["event_hash"]
        return {"valid": True, "events": len(rows), "head": previous}

    def login(self, username: str, password: str) -> dict[str, Any] | None:
        row = self.query_one("SELECT * FROM users WHERE username=? AND active=1", (username,))
        if not row or not verify_password(password, row["salt"], row["password_hash"]):
            return None
        token = issue_token()
        now = utc_now()
        expires_at = expiry()
        with self.transaction() as conn:
            conn.execute("DELETE FROM sessions WHERE expires_at <= ?", (now,))
            conn.execute("INSERT INTO sessions(token,username,expires_at,created_at) VALUES (?,?,?,?)", (token, username, expires_at, now))
            self.append_audit(conn, username, "login", "user", username, {"expires_at": expires_at})
        return {"token": token, "expires_at": expires_at, "user": {"username": username, "display_name": row["display_name"], "role": row["role"]}}

    def authenticate(self, token: str) -> dict[str, Any] | None:
        if not token:
            return None
        row = self.query_one(
            "SELECT s.token,s.expires_at,u.username,u.display_name,u.role,u.active FROM sessions s JOIN users u ON u.username=s.username WHERE s.token=?",
            (token,),
        )
        if not row or not row["active"] or expired(row["expires_at"]):
            return None
        return {"username": row["username"], "display_name": row["display_name"], "role": row["role"], "expires_at": row["expires_at"]}

    def sqlite_version(self) -> str:
        with self.connect() as conn:
            return str(conn.execute("SELECT sqlite_version()").fetchone()[0])


def decode_json_fields(row: dict[str, Any], fields: list[str]) -> dict[str, Any]:
    result = dict(row)
    for field in fields:
        if field in result and isinstance(result[field], str):
            result[field] = json.loads(result[field])
    return result
