from __future__ import annotations

from collections import Counter
from typing import Any

from .constants import DIKWP_CHANNELS
from .util import canonical_json, sha256_text


def build_mesh(
    scenario: dict[str, Any],
    mission: dict[str, Any],
    formal: dict[str, Any],
    simulation: dict[str, Any],
    kernel: dict[str, Any] | None = None,
) -> dict[str, Any]:
    nodes: list[dict[str, Any]] = []
    edges: list[dict[str, Any]] = []
    node_ids: set[str] = set()

    def add_node(node_id: str, role: str, kind: str, label: str, source_state: str, payload: dict[str, Any] | None = None) -> None:
        if node_id in node_ids:
            return
        node_ids.add(node_id)
        nodes.append(
            {
                "id": node_id,
                "role_address": role,
                "kind": kind,
                "label": label,
                "source_state": source_state,
                "payload": payload or {},
            }
        )

    def add_edge(edge_id: str, channel: str, source: str, target: str, relation: str, source_state: str) -> None:
        if source not in node_ids:
            add_node(source, channel.split("→")[0], "external_handle", source, source_state)
        if target not in node_ids:
            add_node(target, channel.split("→")[1], "external_handle", target, source_state)
        edges.append(
            {
                "id": edge_id,
                "channel": channel,
                "source": source,
                "target": target,
                "relation": relation,
                "source_state": source_state,
            }
        )

    for variable in scenario["state_variables"]:
        add_node(
            f"D:state:{variable['id']}",
            "D",
            "state_expression",
            variable.get("label", variable["id"]),
            variable.get("source_state", scenario["source_state"]),
            {"unit": variable.get("unit"), "initial": variable["initial"]},
        )
    for evidence in scenario.get("evidence", []):
        add_node(f"D:evidence:{evidence['id']}", "D", "evidence_expression", evidence["claim"], evidence["source_state"], {"reliability": evidence.get("reliability")})
    for purpose in scenario["purposes"]:
        add_node(f"P:purpose:{purpose['id']}", "P", "purpose_expression", purpose["raw_expression"], purpose["source_state"], {"actor_id": purpose["actor_id"]})
    for action_id in mission["sequence"]:
        action = next(item for item in scenario["actions"] if item["id"] == action_id)
        add_node(f"W:action:{action_id}", "W", "candidate_transition", action["label"], action["source_state"], {"required_authorities": action.get("required_authorities", [])})
    for hypothesis in scenario.get("hypotheses", []):
        add_node(f"K:hypothesis:{hypothesis['id']}", "K", "causal_hypothesis", hypothesis["statement"], hypothesis["source_state"], {})
    add_node("I:scenario_context", "I", "observer_context", scenario["title"], scenario["source_state"], scenario["observer_context"])
    add_node("I:formal_branch_lattice", "I", "compiled_branch_lattice", "bounded branch lattice", "locally_observed", {"terminal_branch_count": formal["terminal_branch_count"]})
    add_node("K:formal_obligations", "K", "proof_obligation_set", "formal proof obligations", "locally_observed", {"count": len(formal["proof_obligations"])})
    add_node("W:closure_state", "W", "closure_gate", formal["closure_state"], "locally_observed", {})
    add_node("P:settlement_contract", "P", "settlement_contract", "pre-registered outcome settlement", scenario["source_state"], {"item_count": len(scenario.get("settlement_contract", []))})

    for purpose_id in mission["purpose_ids"]:
        add_edge(
            f"edge_p_to_i_{purpose_id}",
            "P→I",
            f"P:purpose:{purpose_id}",
            "I:scenario_context",
            "purpose conditions the scenario projection",
            "engineered_candidate",
        )
    for variable in scenario["state_variables"]:
        add_edge(
            f"edge_d_to_i_{variable['id']}",
            "D→I",
            f"D:state:{variable['id']}",
            "I:formal_branch_lattice",
            "state expression is contextualized into a bounded transition lattice",
            "locally_observed",
        )
    for hypothesis in scenario.get("hypotheses", []):
        for evidence_ref in hypothesis.get("evidence_refs", []):
            add_edge(
                f"edge_d_to_k_{evidence_ref}_{hypothesis['id']}",
                "D→K",
                f"D:evidence:{evidence_ref}",
                f"K:hypothesis:{hypothesis['id']}",
                "source-indexed evidence is linked to a causal hypothesis",
                hypothesis["source_state"],
            )
        add_edge(
            f"edge_k_to_i_{hypothesis['id']}",
            "K→I",
            f"K:hypothesis:{hypothesis['id']}",
            "I:formal_branch_lattice",
            "hypothesis supplies declared transition relations",
            hypothesis["source_state"],
        )
    for action_id in mission["sequence"]:
        add_edge(
            f"edge_w_to_i_{action_id}",
            "W→I",
            f"W:action:{action_id}",
            "I:formal_branch_lattice",
            "candidate transition participates in the compiled branch lattice",
            "engineered_candidate",
        )
    add_edge("edge_i_to_k_proof", "I→K", "I:formal_branch_lattice", "K:formal_obligations", "compiled states are examined against proof obligations", "locally_observed")
    add_edge("edge_k_to_w_gate", "K→W", "K:formal_obligations", "W:closure_state", "proof results constrain the closure gate", "locally_observed")
    add_edge("edge_w_to_p_settlement", "W→P", "W:closure_state", "P:settlement_contract", "closure state constrains whether a settlement contract remains open", "locally_observed")
    add_edge("edge_p_to_p_revision", "P→P", "P:settlement_contract", "P:settlement_contract", "observations may revise or retire the bounded purpose contract without claiming universal definition", "engineered_candidate")

    for relation in scenario.get("mesh_relations", []):
        add_edge(relation["id"], relation["channel"], relation["source"], relation["target"], relation["relation"], relation["source_state"])

    if kernel:
        add_node("K:intent_conditioned_kernel", "K", "counterfactual_kernel", "intent-conditioned minimal dependency set", "locally_observed", {"critical_nodes": kernel["critical_node_count"]})
        add_edge("edge_i_to_k_kernel", "I→K", "I:formal_branch_lattice", "K:intent_conditioned_kernel", "counterfactual deletions expose closure-sensitive dependencies", "locally_observed")
        add_edge("edge_k_to_w_kernel", "K→W", "K:intent_conditioned_kernel", "W:closure_state", "closure-sensitive dependencies constrain interpretation of the gate", "locally_observed")

    channel_counts = Counter(edge["channel"] for edge in edges)
    invalid_channels = [edge["channel"] for edge in edges if edge["channel"] not in DIKWP_CHANNELS]
    active_channel_count = len(channel_counts)
    if invalid_channels:
        mesh_state = "M0"
    elif active_channel_count >= 10 and kernel:
        mesh_state = "M4"
    elif active_channel_count >= 8:
        mesh_state = "M3"
    elif active_channel_count >= 4:
        mesh_state = "M2"
    elif active_channel_count >= 1:
        mesh_state = "M1"
    else:
        mesh_state = "M0"

    return {
        "channel_catalog": list(DIKWP_CHANNELS),
        "channel_catalog_count": len(DIKWP_CHANNELS),
        "active_channel_count": active_channel_count,
        "active_channel_counts": dict(sorted(channel_counts.items())),
        "mesh_examination": mesh_state,
        "nodes": nodes,
        "edges": edges,
        "invalid_channels": invalid_channels,
        "mesh_hash": sha256_text(canonical_json({"nodes": nodes, "edges": edges})),
        "boundary": "D/I/K/W/P are inherited runtime role addresses. Channel presence does not assign a universal meaning to the related expressions.",
    }
