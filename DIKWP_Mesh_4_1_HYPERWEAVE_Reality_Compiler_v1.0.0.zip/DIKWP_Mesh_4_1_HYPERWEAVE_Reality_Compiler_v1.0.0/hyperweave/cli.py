from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path
from typing import Any

from .constants import DEFAULT_DB, DEFAULT_HOST, DEFAULT_PORT
from .server import serve
from .service import Service
from .util import atomic_write_text, pretty_json


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="DIKWP-Mesh 4.1 HYPERWEAVE Reality Compiler")
    parser.add_argument("--db", default=None, help="SQLite path; defaults to runtime/hyperweave.sqlite3 under the project root")
    sub = parser.add_subparsers(dest="command", required=True)

    serve_parser = sub.add_parser("serve", help="start the local browser system")
    serve_parser.add_argument("--host", default=DEFAULT_HOST)
    serve_parser.add_argument("--port", type=int, default=DEFAULT_PORT)

    demo = sub.add_parser("demo", help="compile all bundled synthetic missions")
    demo.add_argument("--trials", type=int, default=500)
    demo.add_argument("--seed", type=int, default=20260722)
    demo.add_argument("--max-states", type=int, default=20000)
    demo.add_argument("--out", default="outputs/demo_compilations.json")

    compile_parser = sub.add_parser("compile", help="compile one scenario mission")
    compile_parser.add_argument("--scenario", required=True)
    compile_parser.add_argument("--mission", required=True)
    compile_parser.add_argument("--trials", type=int, default=1000)
    compile_parser.add_argument("--seed", type=int, default=20260722)
    compile_parser.add_argument("--max-states", type=int, default=20000)
    compile_parser.add_argument("--out", default=None)

    sub.add_parser("summary", help="print system counts and status")
    sub.add_parser("verify-audit", help="verify the SHA-256 audit chain")
    sub.add_parser("qa", help="run the complete local QA suite")
    return parser


def _service(root: Path, db_arg: str | None) -> Service:
    db_path = Path(db_arg) if db_arg else root / DEFAULT_DB
    service = Service(root, db_path)
    service.initialize()
    return service


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    root = Path(__file__).resolve().parents[1]
    service = _service(root, args.db)

    if args.command == "serve":
        serve(service, root / "web", args.host, args.port)
        return 0
    if args.command == "summary":
        print(pretty_json(service.health()))
        return 0
    if args.command == "verify-audit":
        result = service.verify_audit()
        print(pretty_json(result))
        return 0 if result["valid"] else 2
    if args.command == "compile":
        result = service.compile(args.scenario, args.mission, "cli", trials=args.trials, seed=args.seed, max_states=args.max_states)
        if args.out:
            out = root / args.out
            atomic_write_text(out, pretty_json(result) + "\n")
            print(out)
        else:
            print(pretty_json(result))
        return 0
    if args.command == "demo":
        rows: list[dict[str, Any]] = []
        for scenario in service.list_scenarios():
            for mission in scenario["missions"]:
                compilation = service.compile(
                    scenario["id"], mission["id"], "cli_demo",
                    trials=args.trials, seed=args.seed, max_states=args.max_states,
                )
                rows.append(
                    {
                        "id": compilation["id"],
                        "scenario_id": compilation["scenario_id"],
                        "mission_id": compilation["mission_id"],
                        "status": compilation["status"],
                        "semantic_stability": compilation["semantic_stability"],
                        "mesh_examination": compilation["mesh_examination"],
                        "evidence_reliability": compilation["evidence_reliability"],
                        "counterexamples": len(compilation["capsule"]["formal"]["counterexamples"]),
                        "capsule_hash": compilation["capsule_hash"],
                    }
                )
        output = {
            "system": service.health()["system_id"],
            "compilation_count": len(rows),
            "items": rows,
            "audit": service.verify_audit(),
        }
        out = root / args.out
        atomic_write_text(out, pretty_json(output) + "\n")
        print(pretty_json(output))
        return 0
    if args.command == "qa":
        completed = subprocess.run([sys.executable, str(root / "tests" / "run_qa.py")], cwd=root, check=False)
        return completed.returncode
    return 2
