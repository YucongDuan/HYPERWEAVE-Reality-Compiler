from __future__ import annotations

import base64
import hashlib
import hmac
import os
import secrets
from datetime import datetime, timedelta, timezone


def hash_password(password: str, salt: str | None = None) -> tuple[str, str]:
    if not isinstance(password, str) or len(password) < 8:
        raise ValueError("password must be at least 8 characters")
    raw_salt = base64.b64decode(salt) if salt else os.urandom(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), raw_salt, 210_000)
    return base64.b64encode(raw_salt).decode("ascii"), base64.b64encode(digest).decode("ascii")


def verify_password(password: str, salt: str, expected: str) -> bool:
    _, actual = hash_password(password, salt)
    return hmac.compare_digest(actual, expected)


def issue_token() -> str:
    return secrets.token_urlsafe(32)


def expiry(hours: int = 12) -> str:
    return (datetime.now(timezone.utc) + timedelta(hours=hours)).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def expired(value: str) -> bool:
    current = datetime.now(timezone.utc)
    target = datetime.fromisoformat(value.replace("Z", "+00:00"))
    return target <= current
