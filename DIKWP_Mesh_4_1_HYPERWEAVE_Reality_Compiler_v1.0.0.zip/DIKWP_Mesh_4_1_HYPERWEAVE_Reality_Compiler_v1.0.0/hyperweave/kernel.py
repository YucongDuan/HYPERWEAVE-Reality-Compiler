from __future__ import annotations

from typing import Any

from .modelcheck import check_mission
from .util import canonical_json, sha256_text


def closure_signature(result: dict[str, Any]) -> dict[str, Any]:
    return {
        "closure_state": result["closure_state"],
        "proof": {item["id"]: item["state"] for item in result["proof_obligations"]},
        "purposes": {item["purpose_id"]: item["aggregate_state"] for item in result["plural_intent_surface"]},
        "outcomes": {item["id"]: item["summary"] for item in result["outcome_surface"]},
        "terminal_branch_count": result["terminal_branch_count"],
    }


def _diff(before: dict[str, Any], after: dict[str, Any]) -> dict[str, Any]:
    changed: dict[str, Any] = {}
    keys = sorted(set(before) | set(after))
    for key in keys:
        if canonical_json(before.get(key)) != canonical_json(after.get(key)):
            changed[key] = {"before": before.get(key), "after": after.get(key)}
    return changed


def derive_intent_conditioned_kernel(
    scenario: dict[str, Any],
    mission: dict[str, Any],
    base_result: dict[str, Any],
    *,
    max_states: int = 20000,
) -> dict[str, Any]:
    baseline = closure_signature(base_result)
    critical_nodes: list[dict[str, Any]] = []
    noncritical_nodes: list[dict[str, Any]] = []

    def test(node: dict[str, Any], result: dict[str, Any]) -> None:
        signature = closure_signature(result)
        differences = _diff(baseline, signature)
        record = dict(node)
        record["counterfactual_changed_closure"] = bool(differences)
        record["differences"] = differences
        (critical_nodes if differences else noncritical_nodes).append(record)

    for index, action_id in enumerate(mission["sequence"]):
        result = check_mission(scenario, mission, max_states=max_states, disabled_sequence_indexes={index})
        test(
            {
                "id": f"action_step:{index}:{action_id}",
                "kind": "action_step",
                "action_id": action_id,
                "sequence_index": index,
                "counterfactual": "replace the step with an explicit no-op",
            },
            result,
        )

    for invariant in scenario["properties"].get("invariants", []):
        result = check_mission(scenario, mission, max_states=max_states, disabled_invariants={invariant["id"]})
        test(
            {
                "id": f"invariant:{invariant['id']}",
                "kind": "proof_obligation",
                "property_id": invariant["id"],
                "counterfactual": "remove the invariant from the bounded checker",
            },
            result,
        )

    for purpose_id in mission["purpose_ids"]:
        result = check_mission(scenario, mission, max_states=max_states, disabled_purposes={purpose_id})
        test(
            {
                "id": f"purpose:{purpose_id}",
                "kind": "purpose",
                "purpose_id": purpose_id,
                "counterfactual": "remove this purpose from the mission surface",
            },
            result,
        )

    for grant in sorted(set(mission.get("authority_grants", []))):
        result = check_mission(scenario, mission, max_states=max_states, removed_authority_grants={grant})
        test(
            {
                "id": f"authority:{grant}",
                "kind": "authority_grant",
                "grant": grant,
                "counterfactual": "remove this authority grant",
            },
            result,
        )

    critical_ids = {item["id"] for item in critical_nodes}
    edges: list[dict[str, Any]] = []
    for index, action_id in enumerate(mission["sequence"]):
        action_node = f"action_step:{index}:{action_id}"
        if action_node not in critical_ids:
            continue
        if index > 0:
            previous = f"action_step:{index - 1}:{mission['sequence'][index - 1]}"
            if previous in critical_ids:
                edges.append({"source": previous, "target": action_node, "relation": "declared_sequence_precedes"})
        for purpose_id in mission["purpose_ids"]:
            purpose_node = f"purpose:{purpose_id}"
            if purpose_node in critical_ids:
                edges.append({"source": purpose_node, "target": action_node, "relation": "mission_step_is_conditioned_by_purpose"})
    for invariant in scenario["properties"].get("invariants", []):
        inv_node = f"invariant:{invariant['id']}"
        if inv_node not in critical_ids:
            continue
        for index, action_id in enumerate(mission["sequence"]):
            action_node = f"action_step:{index}:{action_id}"
            if action_node in critical_ids:
                edges.append({"source": action_node, "target": inv_node, "relation": "transition_is_checked_by_obligation"})

    return {
        "method": "bounded node deletion and relation projection",
        "baseline_signature": baseline,
        "critical_nodes": critical_nodes,
        "noncritical_nodes": noncritical_nodes,
        "critical_edges": edges,
        "critical_node_count": len(critical_nodes),
        "tested_node_count": len(critical_nodes) + len(noncritical_nodes),
        "kernel_hash": sha256_text(canonical_json({"nodes": critical_nodes, "edges": edges})),
        "scope_boundary": "The kernel is valid only for this scenario revision, mission, bounded horizon, expression set and observer/source envelope. It is not a universal essence claim.",
    }
