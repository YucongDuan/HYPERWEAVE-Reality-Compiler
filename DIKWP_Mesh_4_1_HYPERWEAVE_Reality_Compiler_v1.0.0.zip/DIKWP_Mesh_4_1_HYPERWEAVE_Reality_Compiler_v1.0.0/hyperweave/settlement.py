from __future__ import annotations

from typing import Any

from .expressions import ExpressionError, eval_bool, eval_expression
from .util import canonical_json, sha256_text, utc_now


def settle_observation(
    scenario: dict[str, Any],
    mission: dict[str, Any],
    compilation: dict[str, Any],
    observation: dict[str, Any],
) -> dict[str, Any]:
    observed_state = observation.get("state")
    if not isinstance(observed_state, dict) or not observed_state:
        raise ValueError("observation.state must be a non-empty object")
    variable_ids = {item["id"] for item in scenario["state_variables"]}
    unknown = sorted(set(observed_state) - variable_ids)
    if unknown:
        raise ValueError(f"observation contains unknown variables: {unknown}")
    if not observation.get("observer"):
        raise ValueError("observation.observer is required")
    if not observation.get("source_state"):
        raise ValueError("observation.source_state is required")

    contract_results = []
    for item in scenario.get("settlement_contract", []):
        try:
            value = eval_expression(item["expression"], observed_state)
            state = "met" if bool(value) else "not_met"
            error = None
        except ExpressionError as exc:
            value = None
            state = "insufficient_observation"
            error = str(exc)
        contract_results.append(
            {
                "id": item["id"],
                "description": item.get("description", item["id"]),
                "expression": item["expression"],
                "state": state,
                "value": value,
                "error": error,
                "source_state": item.get("source_state"),
            }
        )

    hypothesis_results = []
    for hypothesis in scenario.get("hypotheses", []):
        expression = hypothesis.get("prediction_expression")
        if not expression:
            hypothesis_results.append(
                {
                    "id": hypothesis["id"],
                    "state": "not_evaluated",
                    "reason": "no pre-registered prediction expression",
                    "source_state": hypothesis["source_state"],
                }
            )
            continue
        try:
            supported = eval_bool(expression, observed_state)
            state = "supported_by_observation" if supported else "contested_by_observation"
            error = None
        except ExpressionError as exc:
            state = "insufficient_observation"
            error = str(exc)
        hypothesis_results.append(
            {
                "id": hypothesis["id"],
                "statement": hypothesis["statement"],
                "prediction_expression": expression,
                "state": state,
                "error": error,
                "source_state": hypothesis["source_state"],
            }
        )

    states = {item["state"] for item in contract_results}
    if "not_met" in states:
        settlement_state = "contested"
    elif "insufficient_observation" in states or not contract_results:
        settlement_state = "open"
    else:
        settlement_state = "settled_within_declared_contract"

    result = {
        "settlement_state": settlement_state,
        "scenario_id": scenario["id"],
        "mission_id": mission["id"],
        "compilation_id": compilation["id"],
        "observed_at": observation.get("observed_at") or utc_now(),
        "observer": observation["observer"],
        "source_state": observation["source_state"],
        "scope": observation.get("scope", scenario.get("domain")),
        "observed_state": observed_state,
        "contract_results": contract_results,
        "hypothesis_results": hypothesis_results,
        "evidence_refs": observation.get("evidence_refs", []),
        "authority_effect": "none",
        "boundary": "The settlement compares one source-indexed observation with pre-registered expressions. It does not prove universal causality, truth or transferability.",
    }
    result["settlement_hash"] = sha256_text(canonical_json(result))
    return result
