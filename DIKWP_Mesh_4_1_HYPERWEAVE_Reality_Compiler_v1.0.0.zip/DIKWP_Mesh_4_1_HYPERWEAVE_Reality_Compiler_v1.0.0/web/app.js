"use strict";

const state = {
  token: localStorage.getItem("hyperweave_token") || "",
  user: null,
  health: null,
  portfolio: null,
  modules: [],
  scenarios: [],
  compilations: [],
  settlements: [],
  currentCompilation: null,
  currentBundle: null,
};

const $ = (id) => document.getElementById(id);
const esc = (value) => String(value ?? "")
  .replaceAll("&", "&amp;")
  .replaceAll("<", "&lt;")
  .replaceAll(">", "&gt;")
  .replaceAll('"', "&quot;")
  .replaceAll("'", "&#039;");
const json = (value) => JSON.stringify(value, null, 2);
const shorten = (value, length = 70) => {
  const text = String(value ?? "");
  return text.length > length ? `${text.slice(0, length - 1)}…` : text;
};
const stateClass = (value) => `state-${String(value ?? "").replaceAll(/[^A-Za-z0-9_-]/g, "_")}`;
const badge = (value, extra = "") => `<span class="badge ${stateClass(value)} ${extra}">${esc(value ?? "—")}</span>`;
const statusBox = (label, value) => `<div class="status-box"><span>${esc(label)}</span><strong class="${stateClass(value)}">${esc(value ?? "—")}</strong></div>`;
const formatTime = (value) => value ? new Date(value).toLocaleString("zh-CN", { hour12: false }) : "—";

async function api(path, options = {}) {
  const headers = { "Content-Type": "application/json", ...(options.headers || {}) };
  if (state.token) headers.Authorization = `Bearer ${state.token}`;
  const response = await fetch(path, { ...options, headers });
  let body = null;
  try { body = await response.json(); } catch { body = { error: `HTTP ${response.status}` }; }
  if (response.status === 401) {
    logout(false);
    throw new Error(body.error || "认证失效");
  }
  if (!response.ok) throw new Error(body.error || body.details || `HTTP ${response.status}`);
  return body;
}

function setNotice(id, message, kind = "") {
  const node = $(id);
  if (!node) return;
  node.textContent = message || "";
  node.className = `notice ${kind}`.trim();
}

function showLogin(show) {
  $("loginOverlay").classList.toggle("hidden", !show);
}

function logout(reload = true) {
  state.token = "";
  state.user = null;
  localStorage.removeItem("hyperweave_token");
  showLogin(true);
  if (reload) window.location.reload();
}

async function login(event) {
  event.preventDefault();
  $("loginError").textContent = "";
  try {
    const result = await api("/api/login", {
      method: "POST",
      body: JSON.stringify({ username: $("loginUser").value.trim(), password: $("loginPassword").value }),
    });
    state.token = result.token;
    state.user = result.user;
    localStorage.setItem("hyperweave_token", result.token);
    showLogin(false);
    await loadAll();
  } catch (error) {
    $("loginError").textContent = error.message;
  }
}

function bindNavigation() {
  document.querySelectorAll("#nav button").forEach((button) => {
    button.addEventListener("click", () => {
      document.querySelectorAll("#nav button").forEach((item) => item.classList.toggle("active", item === button));
      document.querySelectorAll(".view").forEach((view) => view.classList.toggle("active", view.id === `view-${button.dataset.view}`));
    });
  });
}

async function loadAll() {
  const [health, user, portfolio, modules, scenarios, compilations, settlements, audit] = await Promise.all([
    api("/api/health"),
    api("/api/me"),
    api("/api/portfolio"),
    api("/api/modules"),
    api("/api/scenarios"),
    api("/api/compilations?limit=100"),
    api("/api/settlements"),
    api("/api/audit?limit=200"),
  ]);
  state.health = health;
  state.user = user;
  state.portfolio = portfolio;
  state.modules = modules.items || [];
  state.scenarios = scenarios.items || [];
  state.compilations = compilations.items || [];
  state.settlements = settlements.items || [];
  renderHeader();
  renderOverview();
  renderPortfolio();
  renderScenarios();
  renderCompilerSelectors();
  renderCompilationLists();
  renderSettlements();
  renderAudit(audit.items || []);
  if (state.compilations.length && !state.currentCompilation) await selectCompilation(state.compilations[0].id);
}

function renderHeader() {
  $("healthBadge").textContent = state.health?.status === "ok" ? "本地运行正常" : "运行异常";
  $("healthBadge").className = `badge ${state.health?.status === "ok" ? "ok" : "danger"}`;
  $("userBadge").textContent = state.user ? `${state.user.display_name} · ${state.user.role}` : "—";
}

function renderOverview() {
  const counts = state.health?.counts || {};
  const metrics = [
    ["公开组合快照", state.portfolio?.meta?.observed_repository_total ?? counts.portfolio_projects ?? 0, "GitHub 观察值"],
    ["策展关系记录", state.portfolio?.meta?.curated_project_count ?? counts.portfolio_projects ?? 0, "不是成熟度排名"],
    ["深读模块接口", counts.module_manifests ?? state.modules.length, "声明式适配"],
    ["有限合成场景", counts.scenarios ?? state.scenarios.length, "无现实执行权"],
    ["实验编译记录", counts.compilations ?? state.compilations.length, "证明胶囊"],
    ["观察结算记录", counts.settlements ?? state.settlements.length, "来源化后验"],
    ["审计事件", counts.audit_events ?? 0, "SHA-256 链"],
    ["审计链", state.health?.audit?.valid ? "valid" : "invalid", `${state.health?.audit?.events ?? 0} events`],
  ];
  $("overviewCards").innerHTML = metrics.map(([label, value, note]) => `<div class="metric"><span>${esc(label)}</span><strong>${esc(value)}</strong><small>${esc(note)}</small></div>`).join("");
  $("latestCount").textContent = state.compilations.length;
  $("latestCompilations").innerHTML = state.compilations.slice(0, 10).map((item) => `
    <button class="stack-item compilation-link" data-compilation="${esc(item.id)}">
      <div class="row"><strong>${esc(item.mission_id)}</strong>${badge(item.status)}</div>
      <p>${esc(item.scenario_id)} · ${esc(item.semantic_stability)} / ${esc(item.mesh_examination)} / ${esc(item.evidence_reliability)}</p>
      <p class="mono">${esc(shorten(item.capsule_hash, 28))}</p>
    </button>`).join("") || `<div class="stack-item muted">尚无编译记录。</div>`;
  bindCompilationLinks();
}

function renderPortfolio() {
  const meta = state.portfolio?.meta || {};
  const items = state.portfolio?.items || [];
  const metrics = [
    ["观察仓库总量", meta.observed_repository_total ?? "—", "GitHub 页面快照"],
    ["Stars 页面值", meta.observed_starred_total ?? "—", "不是质量指标"],
    ["策展项目记录", meta.curated_project_count ?? items.length, "多标签工程组织"],
    ["关系簇", Object.keys(state.portfolio?.clusters || {}).length, "分析者创建"],
  ];
  $("portfolioMeta").innerHTML = metrics.map(([l, v, n]) => `<div class="metric"><span>${esc(l)}</span><strong>${esc(v)}</strong><small>${esc(n)}</small></div>`).join("");
  const clusters = Object.keys(state.portfolio?.clusters || {}).sort();
  const select = $("portfolioCluster");
  const current = select.value;
  select.innerHTML = `<option value="">全部关系簇</option>${clusters.map((c) => `<option value="${esc(c)}">${esc(c)}</option>`).join("")}`;
  select.value = clusters.includes(current) ? current : "";
  $("clusterChips").innerHTML = clusters.map((c) => `<span class="chip">${esc(c)} · ${esc(state.portfolio.clusters[c])}</span>`).join("");
  renderPortfolioRows();
  $("moduleCount").textContent = state.modules.length;
  $("moduleCards").innerHTML = state.modules.map((item) => `
    <div class="card">
      <div class="row"><h4>${esc(item.name || item.id)}</h4>${badge(item.source_state || "source-indexed")}</div>
      <p>${esc(item.public_capability || item.claimed_capability || item.description || "")}</p>
      <p><strong>输入：</strong>${esc((item.inputs || item.input_slots || item.input_artifacts || []).join("、") || "—")}</p>
      <p><strong>输出：</strong>${esc((item.outputs || item.output_slots || item.output_artifacts || []).join("、") || "—")}</p>
      <p><strong>不可继承：</strong>${esc((item.non_inheritance || item.boundaries || item.limitations || []).join("；") || "现实权威")}</p>
      <div class="meta mono">${esc(item.id)} · ${esc(shorten(item.manifest_hash, 24))}</div>
    </div>`).join("");
}

function renderPortfolioRows() {
  const query = $("portfolioSearch").value.trim().toLowerCase();
  const cluster = $("portfolioCluster").value;
  const items = (state.portfolio?.items || []).filter((item) => {
    if (cluster && item.cluster !== cluster) return false;
    if (!query) return true;
    return [item.repo_name, item.claimed_capability, item.cluster, ...(item.integration_slots || [])].join(" ").toLowerCase().includes(query);
  });
  $("portfolioRows").innerHTML = items.map((item) => `
    <tr>
      <td><strong>${esc(item.repo_name)}</strong><div class="mono">${esc(item.id)}</div></td>
      <td>${esc(item.cluster)}</td>
      <td>${esc(item.claimed_capability)}</td>
      <td>${esc((item.integration_slots || []).join("、"))}</td>
      <td>${badge(item.source_state)}<div>${esc(item.evidence_state)}</div></td>
    </tr>`).join("") || `<tr><td colspan="5">无匹配记录。</td></tr>`;
}

function renderScenarios() {
  $("scenarioCards").innerHTML = state.scenarios.map((item) => `
    <div class="card">
      <div class="row"><h4>${esc(item.title)}</h4>${badge(item.source_state)}</div>
      <p><strong>领域：</strong>${esc(item.domain)}</p>
      <p><strong>敏感级：</strong>${esc(item.sensitivity)}</p>
      <p><strong>任务候选：</strong>${esc(item.mission_count)}</p>
      <div class="stack compact">${(item.missions || []).map((mission) => `
        <button class="stack-item mission-link" data-scenario="${esc(item.id)}" data-mission="${esc(mission.id)}">
          <div class="row"><strong>${esc(mission.title)}</strong><span class="badge">${esc(mission.sequence_length)} steps</span></div>
          <p>${esc((mission.module_pipeline || []).join(" → "))}</p>
        </button>`).join("")}</div>
      <div class="meta mono">${esc(item.id)} · revision ${esc(item.revision)} · ${esc(shorten(item.payload_hash, 24))}</div>
    </div>`).join("");
  document.querySelectorAll(".mission-link").forEach((button) => button.addEventListener("click", () => {
    $("compileScenario").value = button.dataset.scenario;
    updateMissionOptions(button.dataset.mission);
    document.querySelector('[data-view="compiler"]').click();
  }));
}

function renderCompilerSelectors() {
  const selected = $("compileScenario").value;
  $("compileScenario").innerHTML = state.scenarios.map((item) => `<option value="${esc(item.id)}">${esc(item.title)}</option>`).join("");
  if (state.scenarios.some((item) => item.id === selected)) $("compileScenario").value = selected;
  updateMissionOptions();
}

function updateMissionOptions(preferred = null) {
  const scenario = state.scenarios.find((item) => item.id === $("compileScenario").value) || state.scenarios[0];
  if (!scenario) return;
  $("compileScenario").value = scenario.id;
  const previous = preferred || $("compileMission").value;
  $("compileMission").innerHTML = scenario.missions.map((mission) => `<option value="${esc(mission.id)}">${esc(mission.title)}</option>`).join("");
  if (scenario.missions.some((mission) => mission.id === previous)) $("compileMission").value = previous;
}

async function compileCurrent() {
  setNotice("compileMessage", "正在展开有限状态分支并搜索反例……");
  $("compileButton").disabled = true;
  try {
    const result = await api("/api/compile", {
      method: "POST",
      body: JSON.stringify({
        scenario_id: $("compileScenario").value,
        mission_id: $("compileMission").value,
        trials: Number($("compileTrials").value),
        seed: Number($("compileSeed").value),
        max_states: Number($("compileMaxStates").value),
      }),
    });
    state.currentCompilation = result;
    setNotice("compileMessage", `编译完成：${result.status} · ${result.id}`, "ok");
    await refreshCompilations();
    renderCurrentCompilation();
  } catch (error) {
    setNotice("compileMessage", error.message, "error");
  } finally {
    $("compileButton").disabled = false;
  }
}

async function refreshCompilations() {
  const data = await api("/api/compilations?limit=100");
  state.compilations = data.items || [];
  renderOverview();
  renderCompilationLists();
}

function renderCompilationLists() {
  const options = state.compilations.map((item) => `<option value="${esc(item.id)}">${esc(item.scenario_id)} / ${esc(item.mission_id)} / ${esc(item.status)}</option>`).join("");
  const settlementValue = $("settlementCompilation").value;
  const exportValue = $("exportCompilation").value;
  $("settlementCompilation").innerHTML = options;
  $("exportCompilation").innerHTML = options;
  if (state.compilations.some((item) => item.id === settlementValue)) $("settlementCompilation").value = settlementValue;
  if (state.compilations.some((item) => item.id === exportValue)) $("exportCompilation").value = exportValue;
}

function bindCompilationLinks() {
  document.querySelectorAll(".compilation-link").forEach((button) => button.addEventListener("click", async () => {
    await selectCompilation(button.dataset.compilation);
    document.querySelector('[data-view="compiler"]').click();
  }));
}

async function selectCompilation(id) {
  if (!id) return;
  state.currentCompilation = await api(`/api/compilations/${encodeURIComponent(id)}`);
  renderCurrentCompilation();
}

function renderCurrentCompilation() {
  const result = state.currentCompilation;
  if (!result) return;
  const capsule = result.capsule || {};
  const formal = capsule.formal || {};
  $("selectedCompilationId").textContent = result.id;
  $("statusDimensions").innerHTML = [
    ["Closure", result.status],
    ["Semantic", result.semantic_stability],
    ["Mesh", result.mesh_examination],
    ["Evidence", result.evidence_reliability],
  ].map(([l, v]) => statusBox(l, v)).join("");
  $("certificateSummary").innerHTML = [
    ["场景 / 任务", `${result.scenario_id} / ${result.mission_id}`],
    ["状态空间", `${formal.explored_branch_count ?? formal.terminal_branch_count ?? "—"} explored · ${formal.terminal_branch_count ?? "—"} terminal`],
    ["证明义务", `${(formal.proof_obligations || []).length} obligations · ${(formal.counterexamples || []).length} counterexamples`],
    ["胶囊哈希", result.capsule_hash],
    ["有限边界", capsule.engineering_handle_boundary || "—"],
  ].map(([l, v]) => `<div class="stack-item"><div class="row"><strong>${esc(l)}</strong><span class="mono truncate" title="${esc(v)}">${esc(shorten(v, 100))}</span></div></div>`).join("");
  $("outcomeSurface").innerHTML = (formal.outcome_surface || []).map((item) => `
    <div class="card"><h4>${esc(item.label || item.id)}</h4><p class="mono">${esc(item.expression)}</p><pre class="json-preview">${esc(json(item.summary))}</pre><div class="meta">${esc(item.unit || "unitless")}</div></div>`).join("") || `<div class="card muted">该任务未声明结果表面。</div>`;
  renderProof(formal);
  renderIntent(capsule);
  renderMesh(capsule.mesh || {});
  if ($("settlementCompilation")) $("settlementCompilation").value = result.id;
  if ($("exportCompilation")) $("exportCompilation").value = result.id;
}

function renderProof(formal) {
  const obligations = formal.proof_obligations || [];
  $("proofCount").textContent = obligations.length;
  $("proofRows").innerHTML = obligations.map((item) => `
    <tr><td><strong>${esc(item.id)}</strong></td><td>${esc(item.kind)}</td><td>${badge(item.state)}</td><td>${badge(item.gate)}</td><td class="mono">${esc(item.expression || item.target || (item.required || []).join(", ") || "—")}</td></tr>`).join("") || `<tr><td colspan="5">尚无证明义务。</td></tr>`;
  const counterexamples = formal.counterexamples || [];
  $("counterexampleCount").textContent = counterexamples.length;
  $("counterexampleList").innerHTML = counterexamples.map((item) => `
    <details class="stack-item">
      <summary><strong>${esc(item.property_id)}</strong> ${badge(item.gate)} · ${esc(item.trace_length)} steps</summary>
      <p>${esc(item.reason)}</p>
      <pre class="json-preview">${esc(json(item.trace || []))}</pre>
    </details>`).join("") || `<div class="stack-item muted">在当前有限模型和边界中未发现反例；这不构成开放世界安全证明。</div>`;
}

function renderIntent(capsule) {
  const surface = capsule.formal?.plural_intent_surface || [];
  $("purposeSurface").innerHTML = surface.map((item) => `
    <div class="card"><div class="row"><h4>${esc(item.actor_id)}</h4>${badge(item.aggregate_state)}</div><p>${esc(item.raw_expression)}</p><p><strong>分支：</strong>${esc(json(item.branch_state_counts))}</p><div class="meta">${esc(item.purpose_id)} · ${esc(item.source_state)}</div></div>`).join("") || `<div class="card muted">尚无目的表面。</div>`;
  const kernel = capsule.intent_conditioned_kernel || {};
  const nodes = kernel.critical_nodes || [];
  $("kernelCount").textContent = kernel.critical_node_count ?? nodes.length;
  $("kernelRows").innerHTML = nodes.map((item) => `
    <tr><td><strong>${esc(item.id || item.node_id)}</strong></td><td>${esc(item.type || item.node_type)}</td><td>${esc(item.counterfactual_operation || item.removal || "delete")}</td><td><pre class="json-preview">${esc(json(item.closure_change || item.changed_signature || item.effect || item))}</pre></td></tr>`).join("") || `<tr><td colspan="4">当前记录未提取关键节点。</td></tr>`;
}

function renderMesh(mesh) {
  const catalog = mesh.channel_catalog || ["D→D","D→I","D→K","D→W","D→P","I→D","I→I","I→K","I→W","I→P","K→D","K→I","K→K","K→W","K→P","W→D","W→I","W→K","W→W","W→P","P→D","P→I","P→K","P→W","P→P"];
  const counts = mesh.active_channel_counts || {};
  const roles = ["D", "I", "K", "W", "P"];
  let matrix = `<div class="mesh-cell head"></div>${roles.map((r) => `<div class="mesh-cell head">→ ${r}</div>`).join("")}`;
  roles.forEach((src) => {
    matrix += `<div class="mesh-cell head">${src} →</div>`;
    roles.forEach((dst) => {
      const channel = `${src}→${dst}`;
      const count = counts[channel] || 0;
      matrix += `<div class="mesh-cell ${count ? "active" : ""}"><strong>${esc(channel)}</strong>${esc(count)}</div>`;
    });
  });
  $("meshMatrix").innerHTML = matrix;
  $("meshState").textContent = mesh.mesh_examination || "—";
  $("meshState").className = `badge ${stateClass(mesh.mesh_examination)}`;
  $("meshSummary").innerHTML = [
    ["通道目录", `${catalog.length} / 25`],
    ["活跃通道", mesh.active_channel_count ?? Object.keys(counts).length],
    ["节点", (mesh.nodes || []).length],
    ["关系边", (mesh.edges || []).length],
    ["无效通道", (mesh.invalid_channels || []).length],
    ["Mesh hash", mesh.mesh_hash || "—"],
  ].map(([l, v]) => `<div class="stack-item"><div class="row"><strong>${esc(l)}</strong><span class="mono">${esc(shorten(v, 42))}</span></div></div>`).join("");
  $("meshRows").innerHTML = (mesh.edges || []).map((edge) => `<tr><td>${badge(edge.channel)}</td><td class="mono">${esc(edge.source)}</td><td>${esc(edge.relation)}</td><td class="mono">${esc(edge.target)}</td><td>${badge(edge.source_state)}</td></tr>`).join("") || `<tr><td colspan="5">尚无激活关系边。</td></tr>`;
}

async function createSettlement() {
  setNotice("settlementMessage", "");
  try {
    const observedState = JSON.parse($("settlementState").value);
    const result = await api("/api/settlements", {
      method: "POST",
      body: JSON.stringify({
        compilation_id: $("settlementCompilation").value,
        observation: {
          observer: $("settlementObserver").value.trim(),
          source_state: $("settlementSource").value,
          state: observedState,
        },
      }),
    });
    setNotice("settlementMessage", `已结算：${result.status} · ${result.id}`, "ok");
    const data = await api("/api/settlements");
    state.settlements = data.items || [];
    renderSettlements();
  } catch (error) {
    setNotice("settlementMessage", error.message, "error");
  }
}

function renderSettlements() {
  $("settlementCount").textContent = state.settlements.length;
  $("settlementList").innerHTML = state.settlements.slice(0, 30).map((item) => `
    <details class="stack-item"><summary><strong>${esc(item.compilation_id)}</strong> ${badge(item.status)}</summary><p>${esc(item.result?.observer)} · ${esc(item.result?.source_state)} · ${esc(formatTime(item.created_at))}</p><pre class="json-preview">${esc(json(item.result))}</pre></details>`).join("") || `<div class="stack-item muted">尚无观察结算。</div>`;
}

async function exportBundle() {
  setNotice("federationMessage", "");
  try {
    state.currentBundle = await api(`/api/compilations/${encodeURIComponent($("exportCompilation").value)}/export`, { method: "POST", body: "{}" });
    $("bundlePreview").textContent = json(state.currentBundle);
    setNotice("federationMessage", "脱敏证明胶囊已生成；完整性不会传递现实权威。", "ok");
  } catch (error) {
    setNotice("federationMessage", error.message, "error");
  }
}

async function importBundle() {
  if (!state.currentBundle) {
    setNotice("federationMessage", "请先导出当前编译的证明胶囊。", "error");
    return;
  }
  try {
    const result = await api("/api/imports", { method: "POST", body: JSON.stringify({ package: state.currentBundle }) });
    setNotice("federationMessage", `导入验证：valid=${result.verification?.valid}; authority_inherited=${result.authority_inherited}`, "ok");
  } catch (error) {
    setNotice("federationMessage", error.message, "error");
  }
}

function renderAudit(items) {
  $("auditRows").innerHTML = items.map((item) => `<tr><td>${esc(item.seq)}</td><td>${esc(formatTime(item.created_at))}</td><td>${esc(item.actor)}</td><td>${esc(item.action)}</td><td>${esc(item.object_type)}:${esc(item.object_id)}</td><td class="mono">${esc(shorten(item.event_hash, 28))}</td></tr>`).join("");
  verifyAudit(false);
}

async function verifyAudit(refreshRows = true) {
  try {
    const result = await api("/api/audit/verify");
    $("auditVerification").innerHTML = [
      ["链状态", result.valid ? "valid" : "invalid"],
      ["事件数", result.events],
      ["链头", shorten(result.head || "—", 28)],
      ["失败序号", result.failed_seq ?? "—"],
    ].map(([l, v]) => statusBox(l, v)).join("");
    if (refreshRows) {
      const audit = await api("/api/audit?limit=200");
      $("auditRows").innerHTML = (audit.items || []).map((item) => `<tr><td>${esc(item.seq)}</td><td>${esc(formatTime(item.created_at))}</td><td>${esc(item.actor)}</td><td>${esc(item.action)}</td><td>${esc(item.object_type)}:${esc(item.object_id)}</td><td class="mono">${esc(shorten(item.event_hash, 28))}</td></tr>`).join("");
    }
  } catch (error) {
    $("auditVerification").innerHTML = statusBox("链状态", error.message);
  }
}

function bindEvents() {
  $("loginForm").addEventListener("submit", login);
  $("logoutButton").addEventListener("click", () => logout());
  $("refreshAll").addEventListener("click", () => loadAll().catch((e) => alert(e.message)));
  $("portfolioSearch").addEventListener("input", renderPortfolioRows);
  $("portfolioCluster").addEventListener("change", renderPortfolioRows);
  $("compileScenario").addEventListener("change", () => updateMissionOptions());
  $("compileButton").addEventListener("click", compileCurrent);
  $("settlementButton").addEventListener("click", createSettlement);
  $("exportButton").addEventListener("click", exportBundle);
  $("importButton").addEventListener("click", importBundle);
  $("verifyAuditButton").addEventListener("click", () => verifyAudit(true));
}

async function boot() {
  bindNavigation();
  bindEvents();
  try {
    const health = await api("/api/health");
    state.health = health;
    if (!state.token) { showLogin(true); return; }
    await loadAll();
    showLogin(false);
  } catch (error) {
    showLogin(true);
    $("loginError").textContent = error.message;
  }
}

document.addEventListener("DOMContentLoaded", boot);
