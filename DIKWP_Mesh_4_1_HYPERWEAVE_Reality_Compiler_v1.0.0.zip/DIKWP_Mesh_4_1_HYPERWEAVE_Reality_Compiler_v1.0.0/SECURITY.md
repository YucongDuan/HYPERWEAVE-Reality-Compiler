# Security Policy

HYPERWEAVE 1.0.0 is a local, synthetic, research and governance prototype. It is not a production authorization system.

Report security issues without including real patient, employee, citizen, research-subject or confidential institutional data. The default demo password is public and must never be treated as a production credential.

The runtime intentionally has no endpoint for shell execution, remote plugin execution, tool invocation, medical-device control or high-impact action. Network exposure beyond `127.0.0.1` is outside the validated release boundary.
